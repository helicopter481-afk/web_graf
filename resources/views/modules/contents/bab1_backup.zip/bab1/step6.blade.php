<section id="step-6" class="step-slide">

    <style>
        /* ========================================= */
        /* CSS KHUSUS UJIAN: FIX ANIMASI & LAYOUT    */
        /* ========================================= */

        /* 1. MATIKAN SEMUA ANIMASI BAWAAN (KUNCI AGAR TIDAK GESER) */
        body.exam-mode,
        body.exam-mode * {
            transition: none !important;
            /* Hentikan efek 'sliding' */
            animation: none !important;
        }

        /* 2. PAKSA WRAPPER AGAR DIAM & FULLSCREEN */
        body.exam-mode .step-slide,
        body.exam-mode .step-active {
            transform: none !important;
            /* Matikan transform agar position fixed jalan */
            position: static !important;
            width: 100% !important;
            height: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
            opacity: 1 !important;
            /* Pastikan langsung muncul tanpa fade-in */
        }

        /* 3. SEMBUNYIKAN ELEMEN PENGGANGGU */
        body.exam-mode aside,
        body.exam-mode header,
        body.exam-mode nav,
        body.exam-mode .sb-container,
        body.exam-mode footer,
        body.exam-mode #navigasi-bawah-asli {
            /* Jika ada */
            display: none !important;
        }

        /* 4. RESET CONTAINER UTAMA LARAVEL */
        body.exam-mode main {
            padding: 0 !important;
            margin: 0 !important;
            width: 100vw !important;
            max-width: none !important;
            transform: none !important;
        }

        body.exam-mode #content-area {
            padding: 0 !important;
            margin: 0 !important;
            width: 100% !important;
            max-width: none !important;
        }

        /* 5. WRAPPER QUIZ MENGUASAI LAYAR (SNAP INSTAN) */
        body.exam-mode #quiz-wrapper {
            position: fixed !important;
            top: 0 !important;
            left: 0 !important;
            right: 0 !important;
            bottom: 0 !important;
            width: 100vw !important;
            height: 100vh !important;
            background: #f8fafc !important;
            /* Background abu */
            z-index: 2147483647 !important;
            /* Z-Index Tertinggi */
            display: flex;
            flex-direction: column;
            margin: 0 !important;
            border-radius: 0 !important;
        }

        /* 6. LAYOUT AREA SOAL */
        body.exam-mode #area-soal {
            flex: 1;
            width: 100%;
            overflow-y: auto;
            padding: 20px 40px;
            background-color: #f8fafc;
            scroll-behavior: auto !important;
            /* Matikan smooth scroll saat ujian */
        }

        /* 7. SIDEBAR KANAN */
        body.exam-mode #sidebar-nav {
            width: 320px;
            flex-shrink: 0;
            border-left: 1px solid #e2e8f0;
            background: white;
            overflow-y: auto;
            z-index: 20;
        }

        /* === Styling Elemen Kecil (Tombol, dll) === */
        .choice-btn {
            background: #fff;
            border: 1px solid #cbd5e1;
            color: #475569;
            padding: 1rem 1rem 1rem 3.5rem;
            position: relative;
            /* transition: 0.2s;  <-- Hapus transition di sini kalau mau tombolnya juga instan */
            border-radius: 0.5rem;
            width: 100%;
            text-align: left;
            margin-bottom: 0.75rem;
        }

        /* Aktifkan kembali transition HANYA untuk hover tombol jika diinginkan */
        body.exam-mode .choice-btn {
            transition: border-color 0.2s, background-color 0.2s !important;
        }

        .choice-btn:hover:not(:disabled) {
            background: #f1f5f9;
            border-color: #94a3b8;
        }

        .choice-selected {
            background: #1e293b !important;
            color: #fff !important;
            border-color: #1e293b !important;
        }

        .badge-key {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            width: 1.8rem;
            height: 1.8rem;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.75rem;
            font-weight: 700;
            border-radius: 4px;
            background: #f1f5f9;
            color: #64748b;
            border: 1px solid #e2e8f0;
        }

        .choice-selected .badge-key {
            background: #475569;
            color: #fff;
            border-color: #475569;
        }

        .nav-btn {
            background: #fff;
            border: 1px solid #e2e8f0;
            color: #64748b;
            font-weight: 600;
        }

        /* Pastikan ini ada di dalam <style> di bagian Step 6 */
        .nav-active {
            background: #1e293b !important;
            color: #fff !important;
            border-color: #1e293b !important;
        }

        .nav-answered {
            background: #15803d !important;
            color: #fff !important;
            border-color: #15803d !important;
        }

        .nav-ragu {
            background: #9ca3af !important;
            color: #fff !important;
            border-color: #9ca3af !important;
        }

        /* Matikan scrollbar body utama saat ujian */
        html.exam-active,
        body.exam-mode {
            overflow: hidden !important;
        }

        /* === STYLE DRAG & DROP === */
        .dnd-container {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .source-zone {
            min-height: 80px;
            padding: 15px;
            background: #f1f5f9;
            border: 2px dashed #cbd5e1;
            border-radius: 10px;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            align-items: center;
        }

        .target-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            /* 2 Kolom di HP */
            gap: 15px;
        }

        @media (min-width: 768px) {
            .target-grid {
                grid-template-columns: repeat(4, 1fr);
            }

            /* 4 Kolom di PC */
        }

        .drop-zone {
            background: white;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            min-height: 120px;
            display: flex;
            flex-direction: column;
        }

        .zone-header {
            padding: 8px;
            font-size: 12px;
            font-weight: 800;
            text-transform: uppercase;
            text-align: center;
            border-bottom: 1px solid #e2e8f0;
            border-radius: 8px 8px 0 0;
        }

        .zone-body {
            flex: 1;
            padding: 10px;
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        /* Warna Zona */
        .zone-vertex {
            border-color: #3b82f6;
        }

        .zone-vertex .zone-header {
            background: #eff6ff;
            color: #1e40af;
            border-color: #dbeafe;
        }

        .zone-edge {
            border-color: #10b981;
        }

        .zone-edge .zone-header {
            background: #ecfdf5;
            color: #047857;
            border-color: #d1fae5;
        }

        .zone-degree {
            border-color: #a855f7;
        }

        .zone-degree .zone-header {
            background: #faf5ff;
            color: #7e22ce;
            border-color: #f3e8ff;
        }

        .zone-distractor {
            border-color: #f43f5e;
        }

        .zone-distractor .zone-header {
            background: #fff1f2;
            color: #be123c;
            border-color: #ffe4e6;
        }

        /* Item Draggable */
        .drag-item {
            padding: 8px 12px;
            background: white;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 600;
            cursor: grab;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            user-select: none;
            touch-action: none;
            /* Penting untuk Mobile */
        }

        .drag-item:active {
            cursor: grabbing;
            border-color: #3b82f6;
        }

        .drag-item.correct {
            background: #dcfce7;
            border-color: #16a34a;
            color: #14532d;
        }

        .drag-item.wrong {
            background: #fee2e2;
            border-color: #ef4444;
            color: #991b1b;
        }

        /* CSS TAMBAHAN UNTUK MODE REVIEW */
        .input-review-wrong {
            background-color: #fee2e2 !important;
            /* Merah muda */
            border-color: #ef4444 !important;
            color: #991b1b !important;
        }

        .input-review-correct {
            background-color: #dcfce7 !important;
            /* Hijau muda */
            border-color: #22c55e !important;
            color: #14532d !important;
        }

        .review-feedback-box {
            margin-top: 20px;
            padding: 15px;
            border-radius: 8px;
            background-color: #f8fafc;
            border: 1px solid #e2e8f0;
        }

        /* Pastikan input disabled tetap hitam jelas */
        input:disabled,
        textarea:disabled {
            color: #334155 !important;
            opacity: 1 !important;
            -webkit-text-fill-color: #334155 !important;
        }
    </style>

    {{-- WRAPPER UTAMA QUIZ --}}
    <div id="quiz-wrapper">
        {{-- HEADER QUIZ --}}
        <div class="h-16 bg-white border-b border-slate-200 flex justify-between items-center px-6 shrink-0 z-30">
            <div>
                <h2 class="font-bold text-slate-800 text-lg">Quiz Materi 1</h2>
                <p class="text-xs text-slate-500">Dasar-Dasar Graf</p>
            </div>
            <div class="flex items-center gap-3 bg-slate-50 px-4 py-2 rounded-lg border border-slate-100">
                <i class="fa-regular fa-clock text-slate-400"></i>
                <div id="timer-display" class="font-mono font-bold text-xl text-slate-800 leading-none">10:00
                </div>
            </div>
        </div>

        {{-- BODY (SPLIT CONTENT: KIRI SOAL, KANAN NAVIGASI) --}}
        <div class="flex flex-1 overflow-hidden relative">

            {{-- KIRI: AREA SOAL --}}
            <div id="area-soal" class="custom-scroll">
                <div class="max-w-4xl mx-auto w-full pt-6 pb-24">

                    @foreach ($quiz1 as $index => $soal)
                        @php
                            $nomor = $index + 1;
                            $qid = 'soal_' . $nomor;
                        @endphp

                        <div id="container-{{ $nomor }}"
                            class="blok-soal {{ $index === 0 ? 'block' : 'hidden' }}">

                            {{-- Label Nomor --}}
                            <div class="flex justify-between items-center mb-4">
                                <span
                                    class="bg-slate-200 text-slate-700 px-3 py-1 rounded text-xs font-bold uppercase tracking-wider">
                                    Soal {{ $nomor }}
                                </span>
                            </div>

                            {{-- Kartu Soal --}}
                            <div class="bg-white border border-slate-200 rounded-xl p-6 shadow-sm mb-6">
                                <div class="question-text text-base font-medium text-slate-800 leading-relaxed">
                                    {!! $soal->question_text !!}
                                </div>
                            </div>

                            {{-- Opsi Jawaban --}}
                            <div class="pl-1">

                                {{-- 1. Pilihan Ganda / Boolean --}}
                                @if (in_array($soal->type, ['MULTIPLE_CHOICE', 'BOOLEAN']))
                                    @if (isset($soal->options) && is_iterable($soal->options))
                                        @foreach ($soal->options as $key => $val)
                                            <button type="button" class="choice-btn group"
                                                onclick="aksiPilihJawaban('{{ $qid }}', '{{ $key }}', this)">
                                                <span class="badge-key">{{ $key }}</span>
                                                <span class="text-sm font-medium">{{ $val }}</span>
                                            </button>
                                        @endforeach
                                    @endif

                                    {{-- 2. Checkbox --}}
                                @elseif($soal->type == 'CHECKBOX')
                                    @if (isset($soal->options) && is_iterable($soal->options))
                                        @foreach ($soal->options as $key => $val)
                                            <label class="choice-btn flex items-center gap-4 cursor-pointer">
                                                <input type="checkbox" name="{{ $qid }}[]"
                                                    value="{{ $key }}"
                                                    class="w-5 h-5 text-slate-900 border-slate-300 rounded focus:ring-slate-900"
                                                    onchange="aksiCekStatus({{ $nomor }})">
                                                <span class="text-sm font-medium">{{ $val }}</span>
                                            </label>
                                        @endforeach
                                    @endif

                                    {{-- 3. Isian Angka / Teks Singkat --}}
                                @elseif($soal->type == 'NUMBER' || $soal->type == 'FILL_BLANK')
                                    <input type="text" id="{{ $qid }}-input"
                                        class="w-full p-4 border border-slate-300 rounded-lg focus:border-slate-800 outline-none font-bold"
                                        placeholder="Ketik jawaban..." oninput="aksiCekStatus({{ $nomor }})"
                                        autocomplete="off">

                                    {{-- 4. Isian Ganda (Tuple) --}}
                                @elseif($soal->type == 'FILL_BLANK_MULTI')
                                    <div class="bg-white border p-6 rounded-lg text-sm">
                                        <p class="mb-2">// Lengkapi:</p>
                                        @php
                                            $jml = 1;
                                            // Cek tipe data correct_answer untuk menentukan jumlah input
                                            if (is_array($soal->correct_answer)) {
                                                $jml = count($soal->correct_answer);
                                            } elseif (is_string($soal->correct_answer)) {
                                                // Deteksi manual koma jika string array
                                                $jml = substr_count($soal->correct_answer, ',') + 1;
                                                // Jika formatnya "["A","B"]", kurangi 1 karena ada koma di dalam array tapi elemen n-1
                                                // Lebih aman pakai regex atau parser sederhana
                                                if (str_contains($soal->correct_answer, '[')) {
                                                    // Coba decode
                                                    $arr = json_decode(str_replace("'", '"', $soal->correct_answer));
                                                    if (is_array($arr)) {
                                                        $jml = count($arr);
                                                    }
                                                }
                                            }
                                            if ($jml < 1) {
                                                $jml = 1;
                                            }
                                        @endphp

                                        @for ($i = 0; $i < $jml; $i++)
                                            <div class="flex gap-2 mb-2 items-center">
                                                <span
                                                    class="text-slate-400 w-6 text-right">[{{ $i + 1 }}]</span>
                                                <input type="text"
                                                    class="input-multi border border-slate-300 rounded px-3 py-2 w-full focus:border-blue-500 outline-none"
                                                    oninput="aksiCekStatus({{ $nomor }})">
                                            </div>
                                        @endfor
                                    </div>

                                    {{-- 5. Drag & Drop --}}
                                @elseif($soal->type == 'DRAG_AND_DROP')
                                    <div class="dnd-container" id="dnd-{{ $qid }}">
                                        {{-- Zona Sumber --}}
                                        <div>
                                            <p class="text-xs font-bold text-slate-500 mb-2">BANK DATA (Tarik ke
                                                kotak di bawah):</p>
                                            <div class="source-zone" data-zone="source">
                                                @php
                                                    // LOGIC BARU: Cek tipe data sebelum decode
                                                    $items = [];
                                                    if (is_string($soal->options)) {
                                                        $items = json_decode($soal->options);
                                                    } elseif (is_array($soal->options)) {
                                                        // Jika sudah array, konversi ke object recursive (jika perlu) atau pakai langsung
                                                        $items = json_decode(json_encode($soal->options));
                                                    }

                                                    if (is_array($items)) {
                                                        shuffle($items);
                                                    }
                                                @endphp

                                                @if (is_array($items))
                                                    @foreach ($items as $item)
                                                        <div class="drag-item" draggable="true"
                                                            data-id="{{ $item->id ?? $loop->index }}"
                                                            id="item-{{ $item->id ?? $loop->index }}">
                                                            {{ $item->text ?? $item }}
                                                        </div>
                                                    @endforeach
                                                @endif
                                            </div>
                                        </div>

                                        {{-- Zona Target --}}
                                        <div class="target-grid">
                                            <div class="drop-zone zone-vertex" data-zone="vertex">
                                                <div class="zone-header">Simpul (Vertex)</div>
                                                <div class="zone-body"></div>
                                            </div>
                                            <div class="drop-zone zone-edge" data-zone="edge">
                                                <div class="zone-header">Sisi (Edge)</div>
                                                <div class="zone-body"></div>
                                            </div>
                                            <div class="drop-zone zone-degree" data-zone="degree">
                                                <div class="zone-header">Derajat</div>
                                                <div class="zone-body"></div>
                                            </div>
                                            <div class="drop-zone zone-distractor" data-zone="distractor">
                                                <div class="zone-header">Bukan Graf</div>
                                                <div class="zone-body"></div>
                                            </div>
                                        </div>
                                    </div>
                                @endif

                            </div>

                            {{-- Feedback Area --}}
                            <div id="feedback-{{ $nomor }}" class="hidden mt-8"></div>
                        </div>
                    @endforeach
                </div>

                {{-- Alert & Footer (Tetap sama) --}}
                <div id="quiz-alert"
                    class="hidden fixed top-20 left-1/2 -translate-x-1/2 bg-red-600 text-white px-6 py-3 rounded-full shadow-xl z-50 font-bold text-sm">
                </div>

                <div id="navigasi-bawah"
                    class="fixed bottom-0 left-0 right-0 md:right-[320px] h-20 bg-white border-t border-slate-200 px-8 flex justify-between items-center z-40">

                    <button id="btn-prev" onclick="aksiGantiSoal(-1)"
                        class="px-5 py-2.5 border border-slate-300 rounded-lg text-slate-600 font-bold text-sm hover:bg-slate-50 disabled:opacity-50">
                        SEBELUMNYA
                    </button>

                    <button id="btn-next" onclick="aksiGantiSoal(1)"
                        class="px-6 py-2.5 bg-slate-900 text-white rounded-lg font-bold text-sm hover:bg-slate-800 shadow-lg">
                        SELANJUTNYA
                    </button>
                </div>
            </div>

            {{-- KANAN: SIDEBAR NAVIGASI --}}
            <div id="sidebar-nav"
                class="hidden md:flex flex-col h-full bg-white border-l border-slate-200 w-[320px] shrink-0 z-30">
                <div class="p-5 border-b border-slate-100">
                    <h4 class="font-bold text-xs text-slate-400 uppercase tracking-widest">Navigasi Soal</h4>
                </div>
                <div class="p-5 flex-1 overflow-y-auto custom-scroll">
                    <div class="grid grid-cols-4 gap-3">
                        @foreach ($quiz1 as $index => $soal)
                            <button onclick="aksiBukaSoal({{ $index + 1 }})" id="nav-btn-{{ $index + 1 }}"
                                class="nav-btn h-10 rounded-lg font-bold text-sm transition flex items-center justify-center">
                                {{ $index + 1 }}
                            </button>
                        @endforeach
                    </div>
                    <div class="mt-6 space-y-3">
                        <button onclick="toggleRagu(soalAktif)"
                            class="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 text-sm font-bold rounded-lg transition">
                            Tandai Ragu-Ragu
                        </button>
                        <button onclick="aksiCekSelesai()"
                            class="w-full py-2 bg-red-600 hover:bg-red-700 text-white text-sm font-bold rounded-lg transition shadow-md">
                            KUMPULKAN
                        </button>
                    </div>
                    {{-- Legend --}}
                    <div class="mt-8 pt-6 border-t border-slate-100 space-y-3 text-xs text-slate-500 font-medium">
                        <div class="flex items-center gap-3"><span class="w-3 h-3 bg-slate-900 rounded-sm"></span>
                            Aktif</div>
                        <div class="flex items-center gap-3"><span class="w-3 h-3 bg-green-700 rounded-sm"></span>
                            Terjawab</div>
                        <div class="flex items-center gap-3"><span class="w-3 h-3 bg-gray-400 rounded-sm"></span>
                            Ragu-ragu</div>
                        <div class="flex items-center gap-3"><span
                                class="w-3 h-3 bg-white border border-slate-300 rounded-sm"></span> Kosong</div>
                    </div>
                </div>
            </div>

        </div>

        {{-- MODAL MULAI (FIXED SCREEN) --}}
        <div id="modal-mulai"
            class="fixed inset-0 bg-white/95 z-[9999] flex items-center justify-center p-4 backdrop-blur-sm">
            <div class="text-center max-w-md w-full">
                <h3 class="text-xl font-bold text-slate-800 mb-2">Siap Mengerjakan?</h3>
                <p class="text-slate-500 mb-8">Waktu 10 menit dimulai setelah klik tombol di bawah.</p>
                <button onclick="aksiMulaiUjian()"
                    class="px-8 py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-lg shadow-lg transition">
                    MULAI UJIAN
                </button>
            </div>
        </div>

        {{-- MODAL KONFIRMASI (FIXED SCREEN) --}}
        <div id="modal-konfirmasi"
            class="fixed inset-0 bg-slate-900/50 z-[9999] flex items-center justify-center p-4 hidden">
            <div class="bg-white rounded-xl p-6 max-w-sm w-full shadow-2xl transform scale-100 transition-transform">
                <h3 class="text-lg font-bold text-slate-800 mb-2">Belum Selesai</h3>
                <p class="text-sm text-slate-600 mb-6">Masih ada soal kosong. Yakin?</p>
                <div class="flex justify-end gap-3">
                    <button onclick="document.getElementById('modal-konfirmasi').classList.add('hidden')"
                        class="px-4 py-2 rounded text-slate-600 hover:bg-slate-50 font-bold text-sm border border-slate-200">BATAL</button>
                    <button onclick="aksiFinalisasi()"
                        class="px-4 py-2 rounded bg-red-600 text-white hover:bg-red-700 font-bold text-sm shadow">YA,
                        KUMPULKAN</button>
                </div>
            </div>
        </div>


        {{-- MODAL HASIL (FIXED SCREEN) --}}
        <div id="modal-hasil" class="fixed inset-0 bg-white z-[9999] flex items-center justify-center p-4 hidden">
            <div class="text-center">
                <div class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">
                    NILAI AKHIR
                </div>

                <div class="text-8xl font-black text-slate-800 mb-6">
                    <span id="skor-akhir">0</span>
                </div>

                <div class="flex gap-3 justify-center">
                    <button onclick="aksiUlangi()"
                        class="px-6 py-3 border border-slate-200 rounded-lg font-bold text-slate-600 hover:bg-slate-50">
                        ULANGI
                    </button>

                    <!-- 🔥 TAMBAHKAN INI -->
                    <button onclick="aksiReviewJawaban()"
                        class="px-6 py-3 bg-slate-800 text-white rounded-lg font-bold hover:bg-slate-900 shadow-lg">
                        LIHAT PEMBAHASAN
                    </button>

                    <a href="{{ route('dashboard') }}"
                        class="px-6 py-3 bg-blue-600 text-white rounded-lg font-bold hover:bg-blue-700 shadow-lg">
                        DASHBOARD
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
<script>
        // ==========================================
        // 1. DATA DARI SERVER (PHP -> JS)
        // ==========================================
        @php
            $displayScore = 0;
            $isDone = false;
            $rawAnswers = null;

            if (isset($progress) && isset($progress['quiz1'])) {
                $dataQuiz = $progress['quiz1'];
                $displayScore = $dataQuiz->score ?? 0;
                $isDone = true;

                // Ambil data jawaban (Array dari Model)
                if (!empty($dataQuiz->answers)) {
                    $rawAnswers = $dataQuiz->answers;
                }
                // Fallback: Cek kolom 'answer' (singular) jika beda nama kolom
                elseif (!empty($dataQuiz->answer)) {
                    $rawAnswers = $dataQuiz->answer;
                }
            }
        @endphp

        // --- VARIABEL GLOBAL ---
        let hasHistory = {{ $isDone ? 'true' : 'false' }};
        let historyScore = {{ $displayScore }};
        const dataSoal = @json($quiz1);

        // VARIABEL STATE
        let totalSoal = dataSoal.length;
        let isExamMode = false;
        let soalAktif = 1;
        let sisaDetik = 600;
        let timerUjian = null;
        let dbRagu = {};

        // [FIX CRITICAL] PARSING JAWABAN DENGAN SAFEKEEPING
        let dbJawabanUser = {};

        try {
            let rawData = @json($rawAnswers);

            if (rawData) {
                // Jika masih string JSON (double encoded), parse dulu
                if (typeof rawData === 'string') {
                    try {
                        rawData = JSON.parse(rawData);
                    } catch (e) {}
                }

                // Normalisasi Format
                if (Array.isArray(rawData)) {
                    // Jika format Array, ubah ke Object {soal_1: val}
                    rawData.forEach((val, idx) => {
                        // Cek jika val adalah object {soal_X: val}
                        if (typeof val === 'object' && val !== null && !Array.isArray(val)) {
                            Object.assign(dbJawabanUser, val);
                        } else {
                            // Jika val adalah jawaban langsung ["A"], mapping manual
                            dbJawabanUser['soal_' + (idx + 1)] = val;
                        }
                    });
                } else if (typeof rawData === 'object' && rawData !== null) {
                    // Jika sudah Object, pakai langsung
                    dbJawabanUser = rawData;
                }
            }
        } catch (e) {
            console.error("Gagal memproses jawaban:", e);
            dbJawabanUser = {}; // Fallback biar gak error
        }

        console.log("🔥 JAWABAN FINAL JS:", dbJawabanUser);

        // ==========================================
        // 2. INISIALISASI HALAMAN
        // ==========================================
        document.addEventListener("DOMContentLoaded", function() {
            if (hasHistory) {
                // MODE: LIHAT HASIL
                let mMulai = document.getElementById('modal-mulai');
                if (mMulai) mMulai.classList.add('hidden');

                let mHasil = document.getElementById('modal-hasil');
                if (mHasil) mHasil.classList.remove('hidden');

                let elSkor = document.getElementById('skor-akhir');
                if (elSkor) elSkor.innerText = historyScore;

                let navBawah = document.getElementById('navigasi-bawah');
                if (navBawah) navBawah.style.display = 'none';

                // Restore Jawaban
                setTimeout(restoreUserAnswers, 500);
            } else {
                // MODE: UJIAN BARU
                if (totalSoal > 0) {
                    aksiBukaSoal(1);
                    initDragAndDrop();
                }
            }
        });

        // ==========================================
        // 3. FUNGSI RESTORE (MENGEMBALIKAN DATA)
        // ==========================================
        function restoreUserAnswers() {
            if (!dbJawabanUser || Object.keys(dbJawabanUser).length === 0) return;

            Object.keys(dbJawabanUser).forEach(key => {
                let answer = dbJawabanUser[key];
                // Bersihkan key: "soal_1" -> "1"
                let nomor = key.toString().replace('soal_', '');
                let container = document.getElementById('container-' + nomor);
                if (!container) return;

                // A. TEXT / FILL BLANK
                let textInputs = container.querySelectorAll('input[type="text"]');
                if (textInputs.length > 0) {
                    if (Array.isArray(answer)) {
                        answer.forEach((val, idx) => {
                            if (textInputs[idx]) textInputs[idx].value = val || "";
                        });
                    } else {
                        textInputs[0].value = answer || "";
                    }
                }

                // B. CHECKBOX
                if (Array.isArray(answer)) {
                    container.querySelectorAll('input[type="checkbox"]').forEach(cb => {
                        if (answer.includes(cb.value) || answer.includes(String(cb.value))) cb.checked =
                            true;
                    });
                }

                // C. PILIHAN GANDA
                container.querySelectorAll('.choice-btn').forEach(btn => {
                    let badge = btn.querySelector('.badge-key');
                    if (badge && String(badge.innerText).trim() == String(answer).trim()) {
                        btn.classList.add('choice-selected');
                        btn.style.backgroundColor = "#1e293b";
                        btn.style.color = "white";
                    }
                });

                // D. DRAG & DROP
                if (typeof answer === 'object' && !Array.isArray(answer)) {
                    Object.keys(answer).forEach(itemId => {
                        let zoneType = answer[itemId];
                        // Cari item berdasarkan data-id atau ID elemen
                        let itemEl = container.querySelector(`.drag-item[data-id="${itemId}"]`) ||
                            document.getElementById(itemId);
                        let targetZone = container.querySelector(
                            `.drop-zone[data-zone="${zoneType}"] .zone-body`);

                        if (itemEl && targetZone) targetZone.appendChild(itemEl);
                    });
                }
            });
            updateTampilanNav();
        }

        // ==========================================
        // 4. FUNGSI REVIEW
        // ==========================================
        function aksiReviewJawaban() {
            document.getElementById('modal-hasil').classList.add('hidden');
            if (timerUjian) clearInterval(timerUjian);
            const timer = document.getElementById('timer-display');
            if (timer) timer.innerText = "REVIEW";

            const navBawah = document.getElementById('navigasi-bawah');
            if (navBawah) {
                navBawah.style.display = "flex";
                if (!document.getElementById('btn-kembali-skor')) {
                    let btn = document.createElement('button');
                    btn.id = 'btn-kembali-skor';
                    btn.innerText = "KEMBALI KE SKOR";
                    btn.className =
                        "px-6 py-2.5 bg-blue-600 text-white rounded-lg font-bold text-sm hover:bg-blue-700 shadow-lg ml-3";
                    btn.onclick = function() {
                        document.getElementById('modal-hasil').classList.remove('hidden');
                        document.getElementById('navigasi-bawah').style.display = 'none';
                    };
                    navBawah.appendChild(btn);
                }
            }

            document.querySelectorAll('[onclick^="toggleRagu"], [onclick="aksiCekSelesai()"]').forEach(btn => btn.style
                .display = "none");
            document.getElementById('sidebar-nav').classList.add('pointer-events-auto');

            restoreUserAnswers();

            // GRADING & VISUALISASI
            dataSoal.forEach((soal, index) => {
                let nomor = index + 1;
                let qid = 'soal_' + nomor;
                let container = document.getElementById('container-' + nomor);
                let feedbackArea = document.getElementById('feedback-' + nomor);
                if (!container) return;

                let userAnswer = dbJawabanUser[qid];
                let rawKunci = soal.correct_answer;
                let isBenar = false;

                try {
                    let u = String(userAnswer || "").trim().toUpperCase();
                    let k = String(rawKunci).trim().replace(/['"]/g, '').toUpperCase();

                    if (soal.type === "CHECKBOX" && Array.isArray(userAnswer)) {
                        let kArr = String(rawKunci).replace(/[\[\]'"]/g, '').split(',').map(x => x.trim()
                            .toUpperCase()).sort();
                        let uArr = userAnswer.map(x => String(x).trim().toUpperCase()).sort();
                        isBenar = (JSON.stringify(kArr) === JSON.stringify(uArr)) && uArr.length > 0;
                    } else if (soal.type === "DRAG_AND_DROP") {
                        if (userAnswer && typeof userAnswer === 'object') {
                            let opts = JSON.parse(soal.options);
                            let correctCount = 0;
                            opts.forEach(o => {
                                if (userAnswer[o.id] === o.category) correctCount++;
                            });
                            isBenar = (correctCount === opts.length);
                        }
                    } else {
                        isBenar = (soal.type === "NUMBER") ? (parseFloat(u) === parseFloat(k)) : (u === k && u !==
                            "");
                    }
                } catch (e) {
                    isBenar = false;
                }

                // DISABLE INPUTS
                container.style.border = "1px solid #e2e8f0";
                container.querySelectorAll('input, button.choice-btn').forEach(el => el.disabled = true);
                container.querySelectorAll('.drag-item').forEach(el => {
                    el.draggable = false;
                    el.style.cursor = 'default';
                });

                // COLORING CHOICE
                if (soal.type === "MULTIPLE_CHOICE" || soal.type === "BOOLEAN") {
                    container.querySelectorAll('.choice-btn').forEach(btn => {
                        let key = btn.querySelector('.badge-key')?.innerText.trim();
                        if (key == userAnswer) {
                            btn.style.backgroundColor = isBenar ? "#dcfce7" : "#fee2e2";
                            btn.style.borderColor = isBenar ? "#22c55e" : "#ef4444";
                            btn.style.color = isBenar ? "#14532d" : "#991b1b";
                        } else {
                            btn.style.backgroundColor = "white";
                        }
                    });
                }
                // COLORING TEXT
                if ((soal.type === "NUMBER" || soal.type === "FILL_BLANK") && userAnswer) {
                    let inp = container.querySelector('input[type="text"]');
                    if (inp) {
                        inp.style.backgroundColor = isBenar ? "#dcfce7" : "#fee2e2";
                        inp.style.borderColor = isBenar ? "#22c55e" : "#ef4444";
                    }
                }

                // FEEDBACK BOX
                if (feedbackArea) {
                    let html =
                        `<div class="mt-6 p-4 rounded-lg border ${isBenar ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}">`;
                    if (isBenar) {
                        html +=
                            `<div class="flex items-center gap-2 mb-2 text-green-700 font-bold"><i class="fa-solid fa-check-circle"></i> JAWABAN BENAR</div>`;
                        if (soal.explanation) html +=
                            `<div class="mt-2 pt-2 border-t border-green-200 text-sm text-slate-700"><strong>Pembahasan:</strong><br>${soal.explanation}</div>`;
                    } else {
                        html +=
                            `<div class="flex items-center gap-2 text-red-700 font-bold"><i class="fa-solid fa-times-circle"></i> KURANG TEPAT</div><p class="text-sm text-red-600 mt-1">Jawaban Anda masih salah atau kosong.</p>`;
                    }
                    html += `</div>`;
                    feedbackArea.innerHTML = html;
                    feedbackArea.classList.remove('hidden');
                }
            });

            aksiBukaSoal(1);
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        }

        // ==========================================
        // 5. HELPER & HANDLERS
        // ==========================================
        function updateTampilanNav() {
            for (let i = 1; i <= totalSoal; i++) {
                let btn = document.getElementById('nav-btn-' + i);
                if (!btn) continue;

                // RESET STYLE DASAR (PUTIH)
                btn.className =
                    "nav-btn h-10 rounded-lg font-bold text-sm transition flex items-center justify-center border";
                btn.style.backgroundColor = "white";
                btn.style.color = "#64748b";
                btn.style.borderColor = "#e2e8f0";

                let terisi = cekApakahTerisi(i);
                let aktif = (i === soalAktif);
                let ragu = dbRagu['soal_' + i];

                if (aktif) {
                    // AKTIF (HITAM)
                    btn.style.backgroundColor = "#1e293b";
                    btn.style.color = "white";
                    btn.style.borderColor = "#0f172a";

                } else if (ragu) {
                    // RAGU (ABU-ABU)
                    btn.style.backgroundColor = "#e5e7eb"; // abu terang
                    btn.style.color = "#374151"; // abu gelap
                    btn.style.borderColor = "#d1d5db";

                } else if (terisi) {
                    // TERISI (HIJAU)
                    btn.style.backgroundColor = "#16a34a";
                    btn.style.color = "white";
                    btn.style.borderColor = "#15803d";
                }
            }
        }



        function cekApakahTerisi(nomor) {
            let qid = 'soal_' + nomor;
            let data = dbJawabanUser[qid];
            if (!data) return false;
            if (Array.isArray(data)) return data.length > 0;
            if (typeof data === 'object') return Object.keys(data).length > 0;
            return String(data).trim() !== "";
        }

        function aksiBukaSoal(nomor) {
            document.querySelectorAll('.blok-soal').forEach(el => el.classList.add('hidden'));
            document.getElementById('container-' + nomor).classList.remove('hidden');
            soalAktif = nomor;
            updateTampilanNav();
            let prev = document.getElementById('btn-prev');
            let next = document.getElementById('btn-next');
            if (prev) prev.disabled = (nomor === 1);
            if (next) {
                if (nomor === totalSoal) next.classList.add('hidden');
                else next.classList.remove('hidden');
            }
        }

        function aksiGantiSoal(arah) {
            let next = soalAktif + arah;
            if (next >= 1 && next <= totalSoal) aksiBukaSoal(next);
        }

        function toggleRagu(nomor) {
            dbRagu['soal_' + nomor] = !dbRagu['soal_' + nomor];
            updateTampilanNav();
        }

        function aksiPilihJawaban(qid, nilai, btn) {
            if (!isExamMode) return;
            dbJawabanUser[qid] = nilai;
            let parent = btn.parentElement;
            parent.querySelectorAll('.choice-btn').forEach(b => {
                b.classList.remove('choice-selected');
                b.style.backgroundColor = "white";
                b.style.color = "#475569";
            });
            btn.classList.add('choice-selected');
            btn.style.backgroundColor = "#1e293b";
            btn.style.color = "white";
            updateTampilanNav();
        }

        function aksiCekStatus(nomor) {
            let qid = 'soal_' + nomor;
            let container = document.getElementById('container-' + nomor);
            let checkboxes = container.querySelectorAll('input[type="checkbox"]');
            if (checkboxes.length > 0) {
                let checked = container.querySelectorAll('input[type="checkbox"]:checked');
                let vals = [];
                checked.forEach(c => vals.push(c.value));
                if (vals.length > 0) dbJawabanUser[qid] = vals;
                else delete dbJawabanUser[qid];
            } else {
                let texts = container.querySelectorAll('input[type="text"]');
                if (texts.length > 0) {
                    let vals = [];
                    let adaIsi = false;
                    texts.forEach(t => {
                        vals.push(t.value);
                        if (t.value.trim()) adaIsi = true;
                    });
                    if (adaIsi) dbJawabanUser[qid] = (texts.length === 1) ? vals[0] : vals;
                    else delete dbJawabanUser[qid];
                }
            }
            updateTampilanNav();
        }

        function initDragAndDrop() {
            const items = document.querySelectorAll('.drag-item');
            const zones = document.querySelectorAll('.drop-zone, .source-zone');
            items.forEach(item => {
                item.addEventListener('dragstart', (e) => {
                    e.dataTransfer.setData('text/plain', e.target.id);
                    e.target.classList.add('opacity-50');
                });
                item.addEventListener('dragend', (e) => {
                    e.target.classList.remove('opacity-50');
                });
            });
            zones.forEach(zone => {
                zone.addEventListener('dragover', (e) => {
                    e.preventDefault();
                    zone.classList.add('bg-blue-50');
                });
                zone.addEventListener('dragleave', (e) => {
                    zone.classList.remove('bg-blue-50');
                });
                zone.addEventListener('drop', (e) => {
                    e.preventDefault();
                    zone.classList.remove('bg-blue-50');
                    const id = e.dataTransfer.getData('text/plain');
                    const draggableElement = document.getElementById(id);
                    if (!draggableElement) return;

                    if (zone.classList.contains('zone-body') || zone.classList.contains('source-zone')) zone
                        .appendChild(draggableElement);
                    else zone.querySelector('.zone-body').appendChild(draggableElement);

                    // SAVE LOGIC: Format Flat (Item ID -> Category)
                    let containerSoal = zone.closest('.blok-soal');
                    if (containerSoal) {
                        let nomorSoal = containerSoal.id.split('-')[1];
                        let qid = 'soal_' + nomorSoal;
                        let answerObj = {};
                        let adaIsi = false;
                        containerSoal.querySelectorAll('.drop-zone').forEach(z => {
                            let cat = z.getAttribute('data-zone');
                            z.querySelectorAll('.drag-item').forEach(i => {
                                let itemId = i.getAttribute('data-id');
                                answerObj[itemId] = cat;
                                adaIsi = true;
                            });
                        });
                        if (adaIsi) dbJawabanUser[qid] = answerObj;
                        else delete dbJawabanUser[qid];
                        updateTampilanNav();
                    }
                });
            });
        }

        // --- SUBMIT ---
        function aksiCekSelesai() {
            let kosong = [];
            for (let i = 1; i <= totalSoal; i++) {
                if (!cekApakahTerisi(i)) kosong.push(i);
            }
            let modal = document.getElementById('modal-konfirmasi');
            let btnConfirm = modal.querySelector('button.bg-red-600');
            let btnCancel = modal.querySelector('button.bg-white');

            if (kosong.length > 0) {
                modal.querySelector('h3').innerText = "Belum Lengkap!";
                modal.querySelector('p').innerHTML = `Belum dijawab: <b>${kosong.join(', ')}</b>`;
                if (btnConfirm) btnConfirm.classList.add('hidden');
                if (btnCancel) btnCancel.innerText = "KEMBALI";
            } else {
                modal.querySelector('h3').innerText = "Selesai?";
                modal.querySelector('p').innerHTML = "Yakin ingin mengumpulkan?";
                if (btnConfirm) btnConfirm.classList.remove('hidden');
                if (btnCancel) btnCancel.innerText = "BATAL";
            }
            modal.classList.remove('hidden');
        }

        function aksiFinalisasi() {
            if (!isExamMode) return;
            clearInterval(timerUjian);
            isExamMode = false;
            document.body.classList.remove('exam-mode');

            const btnKumpul = document.querySelector('#modal-konfirmasi button.bg-red-600');
            if (btnKumpul) {
                btnKumpul.disabled = true;
                btnKumpul.innerText = "Menyimpan...";
            }

            fetch("{{ route('submit.quiz') }}", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "X-CSRF-TOKEN": "{{ csrf_token() }}"
                    },
                    body: JSON.stringify({
                        chapter_code: 'bab1',
                        section_code: 'quiz1',
                        score: 0, // Server menghitung nilai
                        answers: dbJawabanUser // Kirim Object Jawaban
                    })
                })
                .then(res => res.json())
                .then(data => {
                    document.getElementById('skor-akhir').innerText = data.score;
                    document.getElementById('modal-konfirmasi').classList.add('hidden');
                    document.getElementById('modal-hasil').classList.remove('hidden');
                    hasHistory = true;
                    historyScore = data.score;
                })
                .catch(err => {
                    console.error(err);
                    alert("Gagal menyimpan. Cek Console.");
                    if (btnKumpul) {
                        btnKumpul.disabled = false;
                        btnKumpul.innerText = "YA";
                    }
                });
        }

    // --- ULANGI UJIAN (RESET) DENGAN UI MODAL ---
    function aksiUlangi() {
        const modal = document.getElementById('modal-hasil');
        const labelKonfirmasi = modal.querySelector('.text-xs');
        const skorText = modal.querySelector('#skor-akhir');
        
        // 1. Simpan nilai skor sebelumnya untuk dikembalikan nanti
        const skorLama = skorText.innerText; 

        // 2. Ubah tampilan menjadi mode konfirmasi
        labelKonfirmasi.innerText = "KONFIRMASI";
        skorText.innerText = "Ulangi Ujian?";
        skorText.classList.remove('text-8xl'); 
        skorText.classList.add('text-3xl');

        const buttons = modal.querySelectorAll('button');
        const btnUlangi = buttons[0]; 
        const btnLihat = buttons[1];

        btnUlangi.innerText = "YA"; 
        btnLihat.innerText = "BATAL";

        // === FUNGSI RESTORE UI (Kembalikan ke tampilan skor asli) ===
        function restoreModalUI() {
            labelKonfirmasi.innerText = "NILAI AKHIR";
            skorText.innerText = skorLama; // Kembalikan angka
            skorText.classList.add('text-8xl'); 
            skorText.classList.remove('text-3xl');
            
            btnUlangi.innerText = "ULANGI";
            btnLihat.innerText = "LIHAT PEMBAHASAN";
            
            // PENTING: Kembalikan event klik ke fungsi aslinya agar tidak nyangkut
            btnUlangi.onclick = aksiUlangi;
            btnLihat.onclick = aksiReviewJawaban;
        }

        // === AKSI JIKA KLIK "YA" (Reset Kuis) ===
        btnUlangi.onclick = function() {
            // Wajib direstore dulu UI-nya agar saat kuis selesai lagi, tombolnya normal
            restoreModalUI(); 
            modal.classList.add('hidden');

            // Reset Data Variabel
            dbJawabanUser = {}; 
            dbRagu = {}; 
            hasHistory = false; 
            isExamMode = false;

            // Bersihkan Inputan dan Warna
            document.querySelectorAll('input, select').forEach(i => {
                i.value = ''; 
                i.checked = false; 
                i.disabled = false;
                i.style.backgroundColor = 'transparent'; 
                i.style.borderColor = '#cbd5e1';
            });
            
            document.querySelectorAll('.choice-btn').forEach(b => {
                b.classList.remove('choice-selected'); 
                b.disabled = false;
                b.style.backgroundColor = 'white'; 
                b.style.color = '#475569'; 
                b.style.borderColor = '#cbd5e1';
            });

            // Khusus Quiz 1: Kembalikan Drag & Drop (Aman juga jika dipasang di Quiz 2)
            document.querySelectorAll('.drag-item').forEach(d => {
                d.draggable = true;
                d.style.cursor = 'grab';
                let sourceZone = document.querySelector('.source-zone');
                if (sourceZone) sourceZone.appendChild(d);
            });
            
            document.querySelectorAll('[id^="feedback-"]').forEach(f => { 
                f.classList.add('hidden'); 
                f.innerHTML = ''; 
            });
            document.querySelectorAll('.blok-soal').forEach(b => b.style.border = 'none');
            
            // Munculkan kembali Navigasi Bawah
            let navBawah = document.getElementById('navigasi-bawah');
            if (navBawah) navBawah.style.display = 'flex';
            
            let btnKembaliSkor = document.getElementById('btn-kembali-skor');
            if (btnKembaliSkor) btnKembaliSkor.remove();

            // Munculkan kembali tombol Kumpulkan & Ragu-ragu
            document.querySelectorAll('[onclick^="toggleRagu"], [onclick="aksiCekSelesai()"]').forEach(btn => {
                btn.style.display = "block";
            });

            // Tampilkan kembali modal Mulai
            document.getElementById('modal-mulai').classList.remove('hidden');

            updateTampilanNav();
            aksiBukaSoal(1);
            
            // Coba re-init drag & drop jika ada
            if(typeof initDragAndDrop === "function") setTimeout(initDragAndDrop, 500);
        };

        // === AKSI JIKA KLIK "BATAL" ===
        btnLihat.onclick = function() {
            // Langsung kembalikan teks dan wujud tombol ke semula
            restoreModalUI(); 
        };
    }




        // Fungsi Mulai yang sebelumnya dianggap undefined karena crash
        function aksiMulaiUjian() {
            isExamMode = true;
            document.getElementById('modal-mulai').classList.add('hidden');
            document.body.classList.add('exam-mode');
            sisaDetik = 600;
            if (timerUjian) clearInterval(timerUjian);
            timerUjian = setInterval(() => {
                sisaDetik--;
                let m = Math.floor(sisaDetik / 60).toString().padStart(2, '0');
                let s = (sisaDetik % 60).toString().padStart(2, '0');
                if (document.getElementById('timer-display')) document.getElementById('timer-display').innerText =
                    m + ":" + s;
                if (sisaDetik <= 0) aksiFinalisasi();
            }, 1000);
        }
    </script>
