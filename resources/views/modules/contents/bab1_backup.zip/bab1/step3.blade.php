<section id="step-3" class="step-slide">
    {{-- IMPORT VIS JS --}}
    <script type="text/javascript" src="https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"></script>
    <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-10">
        {{-- Header Materi --}}
        <div class="border-b border-slate-200 pb-6 mb-8">
            <h2 class="text-3xl font-bold text-slate-900 mb-2">1.2 Komponen Utama Graf</h2>
            <p class="text-slate-500 font-medium">Memahami elemen pembentuk struktur graf: Simpul, Sisi, dan
                Derajat.
            </p>
        </div>

        <div class="space-y-6 mb-8">
            {{-- TEKS PENGANTAR --}}
            <div class="text-slate-700 leading-relaxed space-y-4">
                <p>Pada submateri sebelumnya telah dijelaskan bahwa komputer memandang dunia nyata melalui
                    proses
                    abstraksi, yaitu menyederhanakan permasalahan kompleks agar dapat diproses secara komputasi.
                    Dalam ilmu komputer, hasil dari proses abstraksi tersebut direpresentasikan dalam bentuk
                    <strong>
                        graf</strong>.
                    Oleh karena itu, pemahaman terhadap komponen utama graf menjadi penting sebelum graf
                    digunakan
                    lebih lanjut dalam perancangan algoritma.
                </p>
                <p>Sebuah graf <em>G</em> didefinisikan sebagai pasangan himpunan ( <em>V</em>, <em>E</em> ), di
                    mana
                    <em>V</em> merupakan himpunan simpul
                    dan <em>E</em> merupakan himpunan sisi yang menghubungkan pasangan simpul. Meskipun definisi
                    ini
                    berasal dari matematika diskrit, dalam konteks ilmu komputer graf lebih dipahami sebagai
                    struktur data yang digunakan untuk memodelkan hubungan antarobjek dalam berbagai bidang
                    ilmu.
                </p>
                <p>Untuk membuka materi pembelajaran lengkap di bawah ini, silakan selesaikan <strong>Misi
                        Laboratorium</strong> terlebih dahulu. Buatlah minimal <strong>3 Titik (Simpul)</strong>
                    dan
                    hubungkan dengan minimal <strong>3 Garis (Sisi)</strong>.</p>
            </div>

            {{-- PANDUAN TOMBOL (SEDERHANA & CLEAN) --}}
            <div class="bg-slate-50 border border-slate-200 rounded-xl p-5">
                <h4 class="text-sm font-bold text-slate-800 mb-4 flex items-center gap-2">
                    Panduan:
                </h4>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {{-- Panduan 1: Tambah Titik --}}
                    <div class="flex items-start gap-3">
                        <div
                            class="mt-1 min-w-[24px] h-6 flex items-center justify-center bg-blue-100 text-blue-600 rounded text-xs font-bold">
                            1</div>
                        <div>
                            <span
                                class="text-xs font-bold text-slate-900 bg-white border border-slate-200 px-2 py-1 rounded shadow-sm mb-1 inline-block">Tambah
                                Titik</span>
                            <p class="text-xs text-slate-600 leading-snug mt-1">Aktifkan mode ini, lalu
                                <strong>klik area kosong</strong> pada kanvas untuk membuat Simpul baru.
                            </p>
                        </div>
                    </div>

                    {{-- Panduan 2: Hubungkan --}}
                    <div class="flex items-start gap-3">
                        <div
                            class="mt-1 min-w-[24px] h-6 flex items-center justify-center bg-slate-200 text-slate-600 rounded text-xs font-bold">
                            2</div>
                        <div>
                            <span
                                class="text-xs font-bold text-slate-700 bg-white border border-slate-200 px-2 py-1 rounded shadow-sm mb-1 inline-block">Hubungkan
                                Titik</span>
                            <p class="text-xs text-slate-600 leading-snug mt-1">Klik & tahan dari satu titik,
                                lalu <strong>tarik garis</strong> ke titik lainnya untuk membuat Sisi.</p>
                        </div>
                    </div>

                    {{-- Panduan 3: Ulangi --}}
                    <div class="flex items-start gap-3">
                        <div
                            class="mt-1 min-w-[24px] h-6 flex items-center justify-center bg-red-100 text-red-600 rounded text-xs font-bold">
                            3</div>
                        <div>
                            <span
                                class="text-xs font-bold text-red-600 bg-red-50 border border-red-100 px-2 py-1 rounded shadow-sm mb-1 inline-block">Ulangi</span>
                            <p class="text-xs text-slate-600 leading-snug mt-1">Jika terjadi kesalahan atau
                                ingin mencoba lagi, tekan tombol ini untuk <strong>reset kanvas</strong>.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- 1. SANDBOX (Main Lab) --}}
        <div class="sb-container">
            <div class="sb-header">
                <h3 class="sb-title">Laboratorium Graf</h3>
                <div class="progress-pill" id="progress-text">PROGRESS: 0/3 TITIK | 0/3 GARIS</div>
            </div>
            <div class="sb-toolbar">
                <button id="btn-node" class="sb-btn active" onclick="setMode('addNode')">Tambah
                    Titik</button>
                <button id="btn-edge" class="sb-btn" onclick="setMode('addEdge')">Hubungkan Titik</button>
                <button class="sb-btn sb-btn-reset" onclick="confirmReset()">Ulangi</button>
            </div>
            <div style="position: relative;">
                <div id="app-toast" class="custom-toast"><span id="toast-icon">⚠️</span> <span
                        id="toast-msg">Error</span></div>
                <div id="reset-modal" class="modal-overlay">
                    <div class="modal-box">
                        <span style="font-size: 30px; margin-bottom: 10px; display: block;">🗑️</span>
                        <span class="modal-title">Ulangi dari awal?</span>
                        <div class="modal-actions mt-4">
                            <button class="btn-cancel" onclick="closeModal()">Batal</button>
                            <button class="btn-confirm" onclick="executeReset()">Ya, Ulangi</button>
                        </div>
                    </div>
                </div>
                <div id="mynetwork"></div>
                <div class="mode-label" id="mode-text">Mode: Klik area kosong untuk menambah titik.</div>
            </div>
        </div>

        {{-- WRAPPER KONTEN TERKUNCI --}}
        <div class="relative min-h-[500px]">
            <div id="main-lock-overlay" class="main-lock-overlay">
                <span>🔒</span><span>Selesaikan Misi Laboratorium di atas untuk membuka materi</span>
            </div>

            <div id="locked-content-area" class="content-locked">
                <p
                    class="text-slate-700 mb-8 font-medium text-center bg-blue-50 p-4 rounded-lg border border-blue-100 text-blue-900">
                    Selamat! Anda telah berhasil membuat representasi visual dari Graf.
                <p>Berdasarkan hasil eksplorasi pada simulasi tersebut, graf tersusun atas beberapa komponen
                    utama
                    berikut.</p>
                </p>

                <div class="section-divider my-10 border-t border-slate-200"></div>

                {{-- MATERI TEKS --}}
                <div class="mb-10">
                    <h3 class="text-xl font-bold text-slate-900 mb-6">Definisi Komponen Graf</h3>
                    <div class="grid gap-6 md:grid-cols-3 mb-8">
                        <div class="bg-slate-50 p-5 rounded-lg border border-slate-200">
                            <div
                                class="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold text-sm mb-3">
                                1</div>
                            <h4 class="font-bold text-slate-900 mb-2">Simpul (Vertex)</h4>
                            <p class="text-sm text-slate-600 mb-3">Objek bulat yang Anda ciptakan pertama kali
                                disebut Simpul atau Vertex.</p>
                            <ul>
                                <li>
                                    <strong>Definisi:</strong> bagian graf yang merepresentasikan entitas atau
                                    objek
                                    data yang bersifat diskrit.
                                </li>
                                <li>
                                    <strong>Notasi:</strong> Dalam himpunan matematika, simpul sering
                                    dinotasikan
                                    sebagai <em>V</em>.
                                </li>
                            </ul>
                        </div>
                        <div class="bg-slate-50 p-5 rounded-lg border border-slate-200">
                            <div
                                class="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold text-sm mb-3">
                                2</div>
                            <h4 class="font-bold text-slate-900 mb-2">Sisi (Edge)</h4>
                            <p class="text-sm text-slate-600 mb-3">Garis yang menghubungkan dua simpul disebut
                                Sisi atau Edge.</p>
                            <ul>
                                <li>
                                    <strong>Definisi:</strong> Komponen yang merepresentasikan relasi atau
                                    hubungan
                                    antara dua simpul.
                                </li>
                                <li>
                                    <strong>Notasi:</strong> Dalam himpunan matematika, sisi sering dinotasikan
                                    sebagai <em>E</em>.
                                </li>
                            </ul>
                        </div>
                        <div class="bg-slate-50 p-5 rounded-lg border border-slate-200">
                            <div
                                class="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold text-sm mb-3">
                                3</div>
                            <h4 class="font-bold text-slate-900 mb-2">Derajat (Degree)</h4>
                            <p class="text-sm text-slate-600 mb-3">Perhatikan jumlah garis yang menempel pada
                                satu
                                simpul.</p>
                            <ul>
                                <li>
                                    <strong>Definisi:</strong> Jumlah sisi yang terhubung langsung dengan simpul
                                    tersebut.
                                </li>
                                <li>
                                    <strong>Notasi:</strong> Derajat dari simpul <em>v</em> dinotasikan sebagai
                                    <em>deg(v)</em>.
                                </li>
                                <li>
                                    <strong>Analogi:</strong> Jika simpul dianalogikan sebagai sebuah rumah,
                                    maka
                                    derajat menunjukkan jumlah jalan yang menuju ke rumah tersebut.
                                </li>
                        </div>
                    </div>

                    {{-- BRIDGING KE JEMBATAN (GABUNGAN FUN FACT) --}}
                    <div class="space-y-6">
                        <div class="bg-indigo-50 border-l-4 border-indigo-500 p-6 rounded-r-lg shadow-sm">
                            <div class="flex items-center gap-2 mb-3">
                                <span class="text-xl">🔍</span>
                                <h4 class="font-bold text-indigo-900 text-lg">Fun Fact Sejarah</h4>
                            </div>
                            <p class="text-slate-700 leading-relaxed text-sm mb-4">
                                Pemahaman mengenai komponen di atas tidak lahir begitu saja. Sejarah mencatat
                                bahwa teori graf pertama kali muncul dari sebuah teka-teki yang membingungkan
                                warga kota Königsberg pada abad ke-18.
                                <strong>Leonhard Euler (1736)</strong> adalah matematikawan pertama yang
                                menyadari bahwa masalah fisik seperti "jembatan" dapat disederhanakan menjadi
                                titik dan garis, melahirkan fondasi teori graf modern.
                            </p>
                        </div>

                        <div
                            class="bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 rounded-t-xl px-6 py-5 shadow-lg">
                            <h4 class="text-xl font-extrabold text-white drop-shadow-md">
                                Tantangan: 7 Jembatan Königsberg
                            </h4>
                        </div>

                        <div class="bg-white rounded-b-xl p-6 border-2 border-orange-300 shadow-md">
                            <div class="text-sm text-slate-700 space-y-3">
                                <p class="leading-relaxed">
                                    Pada tahun 1736, muncul sebuah teka-teki yang membingungkan:
                                    <em class="text-slate-900 font-semibold">"Bisakah melewati semua jembatan
                                        hanya dengan satu kali perjalanan?"</em>
                                </p>

                                <p class="font-semibold text-slate-900">
                                    Cobalah simulasi di bawah ini
                                </p>

                                <div class="bg-slate-50 border border-slate-300 rounded-lg p-4">
                                    <p class="font-semibold text-slate-900 mb-2">Instruksi permainan:</p>
                                    <p class="text-slate-600 mb-3">
                                        Klik daratan (huruf) untuk memulai, kemudian klik jembatan yang menyala
                                        untuk berpindah.
                                    </p>
                                    <p class="text-slate-900">
                                        <strong>Target:</strong> Melewati 7 jembatan tanpa mengulang jalur yang
                                        sama dengan 3 kali kesempatan.
                                    </p>
                                </div>
                            </div>
                        </div>

                        {{-- 2. GAME JEMBATAN (App Container) --}}
                        <div>
                            <div id="app-container">
                                <header class="kg-game-header">
                                    <h2>7 Jembatan Königsberg</h2>
                                    <div class="attempt-box"><span>❤️ Kesempatan:</span> <span
                                            id="attempt-count">3</span>/3</div>
                                </header>
                                <div class="map-wrapper">
                                    <svg viewBox="0 0 900 500" id="game-svg" preserveAspectRatio="xMidYMid meet">
                                        <g id="bridges-layer">
                                            <g id="b1" class="bridge-group"
                                                onclick="crossBridge('b1', 'C', 'A', 280, 140)">
                                                <rect x="265" y="60" width="30" height="170"
                                                    class="bridge-body" transform="rotate(-15 280 140)" />
                                            </g>
                                            <g id="b2" class="bridge-group"
                                                onclick="crossBridge('b2', 'C', 'A', 460, 140)">
                                                <rect x="445" y="60" width="30" height="170"
                                                    class="bridge-body" transform="rotate(15 460 140)" />
                                            </g>
                                            <g id="b3" class="bridge-group"
                                                onclick="crossBridge('b3', 'B', 'A', 280, 360)">
                                                <rect x="265" y="270" width="30" height="170"
                                                    class="bridge-body" transform="rotate(15 280 360)" />
                                            </g>
                                            <g id="b4" class="bridge-group"
                                                onclick="crossBridge('b4', 'B', 'A', 460, 360)">
                                                <rect x="445" y="270" width="30" height="170"
                                                    class="bridge-body" transform="rotate(-15 460 360)" />
                                            </g>
                                            <g id="b5" class="bridge-group"
                                                onclick="crossBridge('b5', 'A', 'D', 630, 250)">
                                                <rect x="540" y="235" width="180" height="30"
                                                    class="bridge-body" />
                                            </g>
                                            <g id="b6" class="bridge-group"
                                                onclick="crossBridge('b6', 'C', 'D', 740, 150)">
                                                <rect x="725" y="70" width="30" height="160"
                                                    class="bridge-body" transform="rotate(-45 740 150)" />
                                            </g>
                                            <g id="b7" class="bridge-group"
                                                onclick="crossBridge('b7', 'B', 'D', 740, 350)">
                                                <rect x="725" y="270" width="30" height="160"
                                                    class="bridge-body" transform="rotate(45 740 350)" />
                                            </g>
                                        </g>
                                        <g id="lands-layer">
                                            <path id="land-C" class="land-shape"
                                                d="M -50,-50 L 950,-50 L 950,80 Q 850,120 700,130 T 400,120 T -50,150 Z"
                                                onclick="setStartNode('C')" />
                                            <path id="land-B" class="land-shape"
                                                d="M -50,550 L 950,550 L 950,420 Q 850,380 700,370 T 400,380 T -50,350 Z"
                                                onclick="setStartNode('B')" />
                                            <path id="land-D" class="land-shape"
                                                d="M 950,80 L 950,420 Q 800,380 750,300 Q 680,250 750,200 Q 800,120 950,80 Z"
                                                onclick="setStartNode('D')" />
                                            <ellipse id="land-A" class="land-shape" cx="370" cy="250"
                                                rx="200" ry="75" onclick="setStartNode('A')" />
                                        </g>
                                        <g id="labels-layer">
                                            <text x="370" y="260" text-anchor="middle" class="region-label">A</text>
                                            <text x="450" y="60" text-anchor="middle" class="region-label">C</text>
                                            <text x="450" y="460" text-anchor="middle" class="region-label">B</text>
                                            <text x="860" y="260" text-anchor="middle" class="region-label">D</text>
                                        </g>
                                        <g id="graph-overlay" class="graph-layer">
                                            <path class="g-edge" d="M 450,60 Q 300,100 370,250" />
                                            <path class="g-edge" d="M 450,60 Q 440,100 370,250" />
                                            <path class="g-edge" d="M 450,440 Q 300,400 370,250" />
                                            <path class="g-edge" d="M 450,440 Q 440,400 370,250" />
                                            <path class="g-edge" d="M 370,250 L 860,250" />
                                            <path class="g-edge" d="M 450,60 Q 700,100 860,250" />
                                            <path class="g-edge" d="M 450,440 Q 700,400 860,250" />
                                            <circle class="g-node" cx="450" cy="60" /> <text
                                                class="g-text" x="450" y="60">C</text>
                                            <circle class="g-node" cx="450" cy="440" /> <text
                                                class="g-text" x="450" y="440">B</text>
                                            <circle class="g-node" cx="370" cy="250" /> <text
                                                class="g-text" x="370" y="250">A</text>
                                            <circle class="g-node" cx="860" cy="250" /> <text
                                                class="g-text" x="860" y="250">D</text>
                                        </g>
                                        <g id="player" class="player-token" transform="translate(10,10)"
                                            style="opacity:0;">
                                            <circle cx="0" cy="0" r="15" fill="#dc2626"
                                                stroke="white" stroke-width="3" />
                                            <circle cx="0" cy="0" r="6" fill="white" />
                                        </g>
                                    </svg>
                                </div>
                                <footer class="kg-footer">
                                    <div class="status-text"><span id="status-icon">📍</span> <span
                                            id="status-text">Klik
                                            huruf A, B, C, atau D untuk mulai.</span></div>
                                    <div>
                                        <button class="btn-graph" onclick="toggleGraph(this)">👁️
                                            Graf</button>
                                        <button class="btn-reset-game" onclick="resetBridgeGame()">🗑️
                                            Reset</button>
                                    </div>
                                </footer>
                            </div>
                            <div id="edu-section">
                                <div class="edu-content">
                                    <h3>💡 Kenapa Selalu Gagal?</h3>
                                    <p>Jangan khawatir! Kegagalanmu membuktikan teori matematika yang ditemukan
                                        oleh <b>Leonhard Euler</b> pada tahun 1736. Ia membuktikan bahwa masalah
                                        Jembatan Königsberg ini <b>MUSTAHIL</b> diselesaikan.</p>
                                    <div class="fact-box"><strong>Syarat Jalur Euler:</strong><br>Sebuah graf
                                        hanya bisa dilalui jika jumlah simpul yang berderajat ganjil adalah
                                        <b>0</b> atau <b>2</b>.
                                    </div>
                                    <p><b>Analisis Peta Ini:</b></p>
                                    <ul>
                                        <li>Wilayah A (Pulau) punya <b>5</b> jembatan (Ganjil).</li>
                                        <li>Wilayah B, C, dan D masing-masing punya <b>3</b> jembatan (Ganjil).
                                        </li>
                                    </ul>
                                    <p>Karena ke-4 wilayah memiliki derajat ganjil, maka mustahil membuat rute
                                        tanpa mengangkat pena. Inilah sejarah lahirnya <b>Teori Graf</b>!</p>
                                    <p style="font-size:13px; color:#64748b; margin-top:10px;"><i>*Sekarang
                                            kamu bisa menekan tombol <b>Reset</b> untuk mencoba lagi.</i></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- BRIDGING KE PYTHON --}}
                <div class="mb-10 pt-8 border-t border-slate-200">
                    <p class="text-slate-700 leading-relaxed mb-6 text-justify">
                        Melalui simulasi Jembatan Königsberg, dapat dipahami bahwa keberhasilan atau kegagalan
                        suatu
                        permasalahan graf ditentukan oleh struktur hubungannya, bukan oleh bentuk visualnya.
                        Oleh
                        karena itu, dalam pemrograman komputer, representasi visual perlu diterjemahkan ke dalam
                        struktur data agar dapat dianalisis secara komputasi. Berikut adalah contoh sederhana
                        representasi graf menggunakan bahasa pemrograman Python.
                    </p>
                    <h3 class="text-xl font-bold text-slate-900 mb-4">Implementasi Python</h3>
                    <div class="space-y-6">
                        <p>Bagaimana merepresentasikan komponen graf visual di atas ke dalam kode program?
                            Komputer
                            tidak menyimpan "gambar lingkaran", melainkan menyimpan struktur data.</p>
                        <div>
                            <h4 class="font-bold text-slate-900 text-sm mb-2 ml-2">A. Menyimpan Simpul</h4>
                            <p class="text-sm text-slate-600 mb-2 ml-6">Simpul disimpan dalam struktur data
                                <strong>List</strong> karena
                                sifatnya dapat bertambah atau berkurang (dinamis), sehingga memungkinkan kita
                                menambah atau menghapus simpul jika data berkembang
                            </p>
                            <div
                                class="bg-slate-900 text-slate-50 p-4 rounded-lg font-mono text-sm border-l-4 border-blue-500 shadow-sm ml-6">
                                nodes = ["A", "B", "C", "D"]</div>
                        </div>
                        <div>
                            <h4 class="font-bold text-slate-900 text-sm mb-2 ml-2">B. Menyimpan Sisi</h4>
                            <p class="text-sm text-slate-600 mb-2 ml-6">Sisi disimpan sebagai pasangan simpul.
                                Perhatikan bahwa kita menggunakan tanda kurung ( ) atau <strong>Tuple</strong>.
                                Alasan menggunakan <em>Tuple</em> adalah karena sifat karena bersifat
                                <em>immutable</em> (tidak bisa diubah
                                isinya). Hal ini menjaga integritas data; jika hubungan A-B putus, kita bukan
                                "mengedit" hubungan itu, melainkan menghapusnya dari daftar sisi
                            </p>
                            <div
                                class="bg-slate-900 text-slate-50 p-4 rounded-lg font-mono text-sm border-l-4 border-green-500 shadow-sm ml-6">
                                edges = [("A", "B"), ("A", "C"), ("B", "D")]</div>
                        </div>
                    </div>
                </div>

                {{-- BRIDGING KE VISUALISASI DERAJAT --}}
                <div class="mb-10 pt-8 border-t border-slate-200">
                    <p class="text-slate-700 leading-relaxed mb-6 text-justify">
                        Selain menyimpan data simpul dan sisi, salah satu properti terpenting dalam graf adalah
                        <strong>Derajat (Degree)</strong>. Seperti yang kita lihat pada kasus Jembatan
                        Königsberg, jumlah derajat menentukan apakah sebuah jalur dapat dilalui atau tidak. Mari
                        kita amati secara langsung bagaimana penambahan sebuah sisi dapat mengubah status
                        derajat simpul secara <i>real-time</i>.
                    </p>

                    {{-- 3. VISUALISASI DERAJAT --}}
                    <h3 class="text-xl font-bold text-slate-900 mb-4">Visualisasi Interaktif: Derajat Simpul
                    </h3>
                    <p class="text-slate-600 mb-6 text-sm leading-relaxed">Perhatikan panel di sebelah kanan
                        graf. Saat ini, simpul C dan D memiliki derajat ganjil yang menandakan ketidakseimbangan
                        koneksi. Silakan tambahkan sisi baru untuk melihat perubahannya.</p>
                    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        <div class="lg:col-span-2">
                            <div id="visNetwork4" class="vis-static-container"></div>
                            <div class="mt-4 flex gap-3">
                                <button id="btnAddEdge" onclick="addEdgeCD()"
                                    class="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-bold transition-all shadow-md flex items-center gap-2"><span>➕</span>
                                    Tambah Sisi (C–D)</button>
                                <button onclick="resetGraph13()"
                                    class="px-5 py-2.5 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-lg text-sm font-semibold transition-all">Reset</button>
                            </div>
                        </div>
                        <div class="lg:col-span-1">
                            <div class="bg-slate-50 rounded-xl border border-slate-200 p-5 h-full">
                                <h4
                                    class="font-bold text-slate-800 border-b border-slate-200 pb-3 mb-3 flex items-center gap-2">
                                    Analisis Derajat
                                </h4>
                                <div class="space-y-3">
                                    <div
                                        class="flex justify-between items-center p-3 bg-white rounded border border-slate-200">
                                        <div class="flex items-center gap-2">
                                            <div class="w-3 h-3 rounded-full bg-blue-500"></div><span
                                                class="text-sm font-semibold text-slate-700">Simpul A</span>
                                        </div><span class="text-sm font-bold text-slate-900">Derajat: 2</span>
                                    </div>
                                    <div
                                        class="flex justify-between items-center p-3 bg-white rounded border border-slate-200">
                                        <div class="flex items-center gap-2">
                                            <div class="w-3 h-3 rounded-full bg-blue-400"></div><span
                                                class="text-sm font-semibold text-slate-700">Simpul B</span>
                                        </div><span class="text-sm font-bold text-slate-900">Derajat: 2</span>
                                    </div>
                                    <div id="info-C"
                                        class="flex justify-between items-center p-3 bg-white rounded border border-slate-200 transition-all duration-500">
                                        <div class="flex items-center gap-2">
                                            <div class="w-3 h-3 rounded-full bg-emerald-500"></div><span
                                                class="text-sm font-semibold text-slate-700">Simpul C</span>
                                        </div><span id="val-C" class="text-sm font-bold text-red-600">Derajat:
                                            1
                                            (Ganjil)</span>
                                    </div>
                                    <div id="info-D"
                                        class="flex justify-between items-center p-3 bg-white rounded border border-slate-200 transition-all duration-500">
                                        <div class="flex items-center gap-2">
                                            <div class="w-3 h-3 rounded-full bg-amber-400"></div><span
                                                class="text-sm font-semibold text-slate-700">Simpul D</span>
                                        </div><span id="val-D" class="text-sm font-bold text-red-600">Derajat:
                                            1
                                            (Ganjil)</span>
                                    </div>
                                </div>
                                <div id="status-box"
                                    class="mt-5 p-3 bg-yellow-50 border border-yellow-200 rounded text-xs text-yellow-800 leading-relaxed font-medium">
                                    ⚠️ Peringatan: Terdapat simpul dengan derajat ganjil. Konektivitas jaringan
                                    belum tertutup sempurna.</div>
                            </div>
                        </div>
                    </div>

                    {{-- PENJELASAN VISUALISASI DERAJAT --}}
                    <div class="mt-6 p-4 bg-slate-50 border border-slate-200 rounded-lg">
                        <p class="text-sm text-slate-700 text-justify">
                            <strong>Analisis Visualisasi:</strong> Pada kondisi awal, Simpul C dan D
                            masing-masing memiliki 1 sisi (derajat 1/ganjil). Ketika Anda menekan tombol
                            <strong>"Tambah Sisi"</strong>, sebuah garis baru menghubungkan C dan D. Hal ini
                            menyebabkan derajat kedua simpul tersebut bertambah 1 menjadi 2 (genap). Perubahan
                            ini menunjukkan prinsip dasar graf bahwa <em>setiap penambahan satu sisi akan selalu
                                menambah total derajat graf sebanyak 2</em>.
                        </p>
                    </div>
                </div>

                <div class="mt-12 pt-8 border-t border-slate-200">
                    <div class="bg-slate-50 border border-slate-200 rounded-lg p-6">

                        <div class="flex items-center gap-3 mb-4">
                            <span
                                class="bg-slate-900 text-white text-xs font-bold px-2 py-1 rounded uppercase">Aktivitas
                                1.2</span>
                            <h4 class="font-bold text-slate-900 text-lg">Studi Kasus: Analisis Jaringan</h4>
                        </div>

                        {{-- CONTAINER SOAL --}}
                        <div class="space-y-8" id="quizContainer12">
                            @foreach ($q1_2 as $index => $soal)
                                @php
                                    // === FIX UTAMA (ANTI ERROR) ===
                                    $kunciBersih = preg_replace('/[^a-zA-Z0-9]/', '', $soal->correct_answer);
                                    $kunciBersih = strtoupper($kunciBersih); // Pastikan Huruf Besar
                                @endphp

                                <div class="quiz-item bg-white border border-slate-200 rounded-xl p-6 shadow-sm"
                                    data-id="q{{ $index + 1 }}" data-correct="{{ $kunciBersih }}">
                                    {{-- Sekarang isinya pasti bersih: C --}}

                                    {{-- Header Soal --}}
                                    <div class="flex gap-2 mb-4 items-baseline">
                                        <span
                                            class="text-slate-500 text-sm leading-relaxed font-medium">{{ $index + 1 }}.</span>
                                        <div class="question-text text-sm leading-relaxed flex-1 text-slate-800">
                                            {!! $soal->question_text !!}
                                        </div>
                                    </div>

                                    {{-- Opsi Jawaban --}}
                                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                        @foreach ($soal->options as $key => $text)
                                            {{-- Pastikan Key Opsi juga bersih --}}
                                            @php $keyBersih = preg_replace('/[^a-zA-Z0-9]/', '', $key); @endphp

                                            <button type="button"
                                                class="option-btn w-full text-left p-3 rounded border border-slate-200 hover:bg-slate-50 transition-colors flex items-start gap-2 group"
                                                onclick="selectOption12('q{{ $index + 1 }}', '{{ $keyBersih }}', this)"
                                                data-option="{{ $keyBersih }}">

                                                <span
                                                    class="option-key font-bold text-slate-500">{{ $key }}.</span>
                                                <span class="option-text text-slate-600">{{ $text }}</span>
                                            </button>
                                        @endforeach
                                    </div>

                                    {{-- Pembahasan --}}
                                    <div id="fb-q{{ $index + 1 }}-12"
                                        class="hidden mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg text-sm text-slate-700 leading-relaxed">
                                        <strong class="block text-blue-800 mb-1">💡 Pembahasan:</strong>
                                        {!! $soal->explanation !!}
                                    </div>
                                </div>
                            @endforeach
                        </div>

                        {{-- FOOTER / STATUS --}}
                        <div class="mt-8 pt-6 border-t border-slate-200">
                            @if ($p1_2)
                                {{-- JIKA SUDAH SELESAI --}}
                                <div
                                    class="bg-green-100 border border-green-400 text-green-800 px-5 py-4 rounded-lg flex items-center gap-4 shadow-sm mb-4">
                                    <div class="text-2xl"></div>
                                    <div>
                                        <h4 class="font-bold text-lg">Aktivitas Selesai!</h4>
                                        <p class="text-sm">Skor: <strong>{{ $p1_2->score }}</strong>. Lihat
                                            pembahasan di atas.</p>
                                    </div>
                                </div>

                                {{-- SCRIPT: LOGIKA SAMA PERSIS DENGAN 1.1 --}}
                                <script>
                                    document.addEventListener("DOMContentLoaded", function() {
                                        // Ambil Data Kunci dari Variable Global
                                        // Pastikan variabel window.quizData12 sudah ada di bagian bawah file
                                        const quizData = window.quizData12;

                                        // Loop setiap container soal
                                        const container = document.getElementById('quizContainer12');
                                        const items = container.querySelectorAll('.quiz-item');

                                        items.forEach(item => {
                                            // Ambil ID Soal dari atribut HTML (misal: q1)
                                            const qId = item.getAttribute('data-id');

                                            // Ambil Kunci Jawaban dari JS Data (Lebih Aman)
                                            // Jika tidak ada di JS, fallback ke atribut data-correct
                                            let correctKey = "";
                                            if (quizData && quizData[qId]) {
                                                correctKey = quizData[qId].correct;
                                            } else {
                                                correctKey = item.getAttribute('data-correct');
                                            }

                                            // 1. Buka Pembahasan
                                            const fb = item.querySelector('[id^="fb-q"]');
                                            if (fb) fb.classList.remove('hidden');

                                            // 2. Loop Tombol & Warnai
                                            const btns = item.querySelectorAll('.option-btn');
                                            btns.forEach(btn => {
                                                // Matikan fungsi klik
                                                btn.disabled = true;
                                                btn.classList.add('cursor-default');
                                                // Hapus hover effect bawaan
                                                btn.classList.remove('hover:bg-slate-50', 'group');

                                                // Ambil Data Opsi Tombol
                                                const btnKey = btn.getAttribute('data-option');

                                                // BANDINGKAN (Case Insensitive & Trim)
                                                if (String(btnKey).trim().toUpperCase() === String(correctKey).trim()
                                                    .toUpperCase()) {
                                                    // === JAWABAN BENAR (HIJAU TERANG) ===
                                                    btn.classList.remove('hover:bg-slate-50', 'border-slate-200');
                                                    btn.classList.add('correct-answer');


                                                } else {
                                                    // === JAWABAN SALAH (REDUP) ===
                                                    btn.classList.add('opacity-50', 'grayscale');
                                                }
                                            });
                                        });

                                        // Buka Tombol Next
                                        const btnNext = document.getElementById('btnNext12');
                                        if (btnNext) {
                                            btnNext.disabled = false;
                                            btnNext.classList.remove('opacity-50', 'cursor-not-allowed');
                                        }
                                    });
                                </script>
                            @else
                                {{-- JIKA BELUM SELESAI --}}
                                <div id="msg-warning-12"
                                    class="hidden mb-4 p-3 bg-yellow-50 border border-yellow-200 text-yellow-800 text-sm rounded text-center">
                                    ⚠️ Mohon jawab semua pertanyaan.</div>
                                <div id="msg-error-12"
                                    class="hidden mb-4 p-3 bg-red-50 border border-red-200 text-red-800 text-sm rounded text-center">
                                    ❌ Jawaban salah.</div>
                                <div class="flex justify-end">
                                    <button onclick="checkAnswers12()"
                                        class="px-6 py-2.5 bg-slate-800 text-white text-sm font-bold rounded hover:bg-slate-900 transition-all shadow-sm active:scale-95">
                                        Periksa Analisis
                                    </button>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>

                <div class="flex justify-between gap-4 mt-12">
                    <button type="button" onclick="prevStep()" class="btn-secondary">← Kembali</button>
                    <button id="btnNext12" type="button" onclick="nextStep()"
                        class="btn-primary opacity-50 cursor-not-allowed" disabled>Lanjut →</button>
                </div>
            </div>

            {{-- Script Data Soal (Penting untuk fungsi klik manual) --}}
            <script>
                window.quizData12 = {
                    @foreach ($q1_2 as $index => $soal)
                        'q{{ $index + 1 }}': {
                            correct: '{{ strtoupper(trim(str_replace(["\"", "'"], '', $soal->correct_answer))) }}',
                            weight: {{ $soal->weight ?? 10 }},
                            explanation: `{!! addslashes($soal->explanation) !!}`
                        }
                        @if (!$loop->last)
                            ,
                        @endif
                    @endforeach
                };
            </script>

</section>
