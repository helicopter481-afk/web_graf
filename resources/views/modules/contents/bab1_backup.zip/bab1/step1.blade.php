<section id="step-1" class="step-slide hidden">
    <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-8 md:p-10">
        <div class="grid md:grid-cols-2 gap-12">

            {{-- Kolom Kiri: Konsep --}}
            <div>
                <div class="text-slate-600 leading-relaxed space-y-4 text-justify">
                    <p>
                        Secara sederhana, graf menyederhanakan dunia nyata menjadi sekumpulan <strong>titik
                            (simpul)</strong> yang disatukan oleh <strong>garis (sisi)</strong>.
                    </p>
                    <p>
                        Konsep ini persis seperti dermaga-dermaga di Banjarmasin (sebagai titik) yang saling
                        dihubungkan oleh alur sungai (sebagai garis).
                    </p>


                    <p>
                        Pada materi ini, kita akan fokus memahami "cara pandang" tersebut: bagaimana komputer
                        melihat dan menyimpan hubungan antarobjek, sebagai pondasi wajib sebelum kita masuk ke
                        teori yang lebih dalam.
                    </p>
                </div>
            </div>

            {{-- Kolom Kanan: Tujuan (Bullet List Bersih) --}}
            <div class="bg-slate-50 rounded-xl p-6 border border-slate-100">
                <h3 class="text-lg font-bold mb-4 text-slate-900">
                    Tujuan Pembelajaran
                </h3>
                <p class="text-sm text-slate-600 mb-4">
                    Setelah menyelesaikan materi ini, mahasiswa diharapkan mampu:
                </p>

                {{-- Bullet List Standar --}}
                <ul class="list-disc pl-5 space-y-3 text-slate-700 text-sm leading-relaxed marker:text-blue-500">
                    <li>
                        Menganalisis konsep graf serta perannya dalam menggambarkan hubungan antar objek.
                    </li>
                    <li>
                        Menganalisis simpul, sisi, dan derajat sebagai komponen utama graf berdasarkan
                        visualisasi dan representasi datanya.
                    </li>
                    <li>
                        Menilai penggunaan graf dalam berbagai contoh kehidupan nyata dan dunia komputer.
                    </li>
                </ul>
            </div>

        </div>

        <div class="section-divider my-8 border-t border-slate-100"></div>

        {{-- Footer Navigasi --}}
        <div class="flex justify-end gap-3">
            <button type="button" onclick="prevStep()"
                class="px-4 py-2 rounded-lg border border-slate-300 text-slate-600 hover:bg-slate-50 text-sm font-medium transition-colors">
                Kembali
            </button>
            <button type="button" onclick="nextStep()"
                class="px-5 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 text-sm font-medium shadow-sm transition-colors">
                Lanjut ke Materi
            </button>
        </div>
    </div>
</section>
