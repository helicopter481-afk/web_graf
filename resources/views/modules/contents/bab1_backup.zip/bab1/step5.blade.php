<section id="step-5" class="step-slide">
    <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-10">
        <h2 class="text-3xl font-bold mb-6 text-slate-900 border-b pb-4">
            Rangkuman Bab 1
        </h2>

        <div class="text-slate-700 text-base leading-relaxed">
            <ul class="list-disc list-outside ml-6 space-y-4">
                <li>
                    Graf digunakan oleh komputer untuk merepresentasikan hubungan antarobjek melalui proses
                    abstraksi, yaitu menyederhanakan permasalahan dunia nyata agar dapat diproses secara komputasi.
                </li>
                <li>
                    Sebuah graf tersusun atas komponen utama berikut:
                    <ul class="list-disc list-outside ml-6 mt-2 space-y-2">
                        <li><strong>Simpul (Vertex):</strong> Mewakili entitas atau objek data, seperti lokasi
                            kota atau akun pengguna.</li>
                        <li><strong>Sisi (Edge):</strong> Mewakili hubungan antar-entitas, seperti jalan raya
                            atau pertemanan.</li>
                        <li><strong>Derajat (Degree):</strong> Menyatakan jumlah sisi yang terhubung pada sebuah
                            simpul. Semakin tinggi derajatnya, semakin tinggi tingkat keterhubungan simpul
                            tersebut.</li>
                    </ul>
                </li>
                <li>
                    Graf berfungsi sebagai <strong>metode abstraksi</strong> bagi komputer untuk menyederhanakan
                    permasalahan dunia
                    nyata. Detail visual yang kompleks diubah menjadi struktur logika berupa simpul dan sisi
                    sehingga dapat diproses secara komputasi.
                </li>
                <li>Melalui graf, permasalahan dunia nyata dapat dianalisis berdasarkan struktur hubungan, bukan
                    berdasarkan bentuk fisiknya. Pendekatan ini memungkinkan komputer melakukan perhitungan dan
                    pengambilan keputusan secara sistematis.</li>
                <li>Konsep graf menjadi fondasi bagi berbagai teknologi modern, antara lain:
                    <ul class="list-disc list-outside ml-6 mt-2 space-y-2">
                        <li><strong>Sistem transportasi dan navigasi:</strong> Digunakan untuk memodelkan jaringan
                            jalan
                            dan menentukan rute yang efisien.</li>
                        <li><strong>Jejaring sosial:</strong> Digunakan untuk menganalisis hubungan pertemanan dan
                            membangun sistem rekomendasi koneksi antar pengguna.</li>
                    </ul>
                </li>
            </ul>
        </div>

        {{-- Navigasi --}}
        <div class="flex justify-between gap-4 mt-12 pt-6 border-t border-slate-200">
            <button type="button" onclick="prevStep()" class="btn-secondary">
                ← Kembali ke Aktivitas 1.3
            </button>
            <button type="button" onclick="nextStep()" class="btn-primary">
                Lanjut ke Quiz →
            </button>
        </div>
    </div>
</section>
