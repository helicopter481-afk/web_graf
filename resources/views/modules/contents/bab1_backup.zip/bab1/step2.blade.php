<section id="step-2" class="step-slide">
    <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-10">

        {{-- Header --}}
        <div class="border-b border-slate-200 pb-6 mb-8">
            <h2 class="text-3xl font-bold text-slate-900 mb-2">
                1.1 Mengapa Kita Perlu Graf?
            </h2>
            <p class="text-slate-500 font-medium">
                Peran abstraksi graf dalam menyelesaikan permasalahan komputasi.
            </p>
        </div>

        {{-- Pengantar --}}
        <div class="mb-8 text-slate-700 leading-relaxed space-y-4 text-justify">
            <p>
                Dalam era teknologi informasi, sistem digital dituntut untuk mampu menyelesaikan permasalahan
                kompleks secara efisien. Contoh nyata dari tuntutan ini terlihat pada aplikasi sehari-hari,
                seperti Google Maps yang dapat menentukan rute tercepat menuju suatu lokasi, atau media sosial
                yang mampu merekomendasikan koneksi pertemanan yang relevan.
            </p>
            <p>
                Di balik kemudahan fitur-fitur tersebut, komputer tidak memandang peta atau foto profil secara
                visual layaknya manusia. Komputer memproses informasi dalam bentuk <strong>struktur
                    diskrit</strong>, yaitu
                representasi data yang terdiri dari objek-objek terpisah beserta hubungan di antaranya.
                <strong>Graf</strong>
                merupakan struktur diskrit yang digunakan untuk menggambarkan hubungan antarobjek di berbagai
                bidang ilmu. Melalui struktur ini, komputer dapat mengolah data secara sistematis dan
                algoritmik.
            </p>

            <p>
                Bagi manusia, representasi dunia nyata memang tampak kaya akan detail visual. Namun, persoalan
                dunia nyata yang kompleks perlu disederhanakan agar dapat diproses oleh komputer. Proses
                penyederhanaan ini dikenal sebagai <strong>abstraksi</strong>, yaitu upaya mengambil informasi
                yang relevan dan
                mengabaikan detail visual yang tidak diperlukan untuk perhitungan.
            </p>

            <p>
                Melalui proses abstraksi, objek-objek dunia nyata direpresentasikan ke dalam bentuk graf yang
                tersusun atas dua komponen utama, yaitu <strong>simpul (<em>vertex</em>)</strong> dan
                <strong>sisi (<em>edge</em>)</strong>. Tanpa konversi ke dalam
                struktur graf, komputer tidak dapat melakukan kalkulasi algoritmik secara efisien dalam
                menyelesaikan suatu permasalahan.
            </p>

            <p>
                Perhatikan ilustrasi perbandingan berikut untuk memahami perbedaan persepsi antara manusia dan
                komputer:
            </p>
        </div>

        {{-- Ilustrasi --}}
        <div class="mb-10">
            <div class="grid md:grid-cols-2 gap-6">
                <div>
                    <div class="border border-slate-200 rounded-lg overflow-hidden mb-2 shadow-sm">
                        <img src="{{ asset('images/peta_kota_visual.png') }}" alt="Perspektif Visual Dunia Nyata"
                            class="w-full h-auto object-cover">
                    </div>
                    <p class="text-xs text-center font-bold text-slate-500 uppercase tracking-wide">
                        Perspektif Visual (Dunia Nyata)
                    </p>
                </div>

                <div>
                    <div class="border border-slate-200 rounded-lg overflow-hidden mb-2 shadow-sm">
                        <img src="{{ asset('images/peta_kota_graf.png') }}" alt="Perspektif Komputasi Graf"
                            class="w-full h-auto object-cover">
                    </div>
                    <p class="text-xs text-center font-bold text-slate-500 uppercase tracking-wide">
                        Perspektif Komputasi (Abstraksi Graf)
                    </p>
                </div>
            </div>
        </div>

        {{-- Penjelasan --}}
        <div class="mb-10 text-slate-700 leading-relaxed space-y-6 text-justify">
            <p>
                Berdasarkan ilustrasi tersebut, terlihat adanya proses abstraksi data dari dunia nyata ke dunia
                komputasi sebagai berikut.
            </p>

            <ol class="space-y-6 list-decimal pl-5 marker:font-bold marker:text-slate-900">
                <li class="pl-2">
                    <strong>Perspektif Visual (Dunia Nyata):</strong>
                    Gambar di sebelah kiri menampilkan peta kota dengan detail visual yang kompleks, seperti
                    gedung, pepohonan, dan variasi lebar jalan. Detail ini penting bagi manusia, tetapi tidak
                    seluruhnya relevan untuk perhitungan rute.
                </li>

                <li class="pl-2">
                    <strong>Perspektif Komputasi (Abstraksi Graf):</strong>
                    Gambar di sebelah kanan menunjukkan bagaimana komputer menyederhanakan peta tersebut.
                    Persoalan dunia nyata direpresentasikan ke dalam graf dengan memetakan objek sebagai simpul
                    dan hubungan antarobjek sebagai sisi:
                </li>
            </ol>

            {{-- Komponen Graf --}}
            <div class="grid sm:grid-cols-2 gap-4 mt-4 ml-6">
                <div class="bg-slate-50 border border-slate-200 p-4 rounded-lg">
                    <strong class="block text-slate-900 mb-1">
                        Simpul (Vertex)
                    </strong>
                    <span class="text-sm text-slate-600">
                        Merepresentasikan entitas (Contoh: Lokasi Rumah, Kampus).
                    </span>
                </div>

                <div class="bg-slate-50 border border-slate-200 p-4 rounded-lg">
                    <strong class="block text-slate-900 mb-1">
                        Sisi (Edge)
                    </strong>
                    <span class="text-sm text-slate-600">
                        Merepresentasikan relasi atau jalur (Contoh: Jalan raya yang menghubungkan dua lokasi).
                    </span>
                </div>
            </div>

            {{-- Definisi Graf
                    <div class="bg-blue-50 border-l-4 border-blue-600 p-5 rounded-md text-slate-800 font-medium">
                        <strong>Graf</strong> bukan sekadar gambar berupa titik dan garis,
                        melainkan sebuah <em>alat pemodelan (modeling tool)</em> yang
                        digunakan komputer untuk memahami struktur persoalan dan
                        mencari solusinya secara sistematis.
                    </div> --}}

            <p>
                Dengan demikian, graf bukan sekadar gambar berupa titik dan garis, melainkan <strong>alat
                    pemodelan
                    (<em>modeling tool</em>)</strong> yang digunakan komputer untuk memahami struktur
                vital bagi komputer untuk memahami struktur suatu persoalan. Algoritma graf
                menjadi fondasi dalam penyelesaian berbagai masalah sulit, seperti pencarian jalur terpendek
                (<em>shortest path</em>), penentuan aliran jaringan maksimum, hingga analisis jaringan sosial.
            </p>
        </div>

        {{-- Referensi --}}
        <p class="text-xs text-slate-500 mt-8">
            Referensi: Rosen (2019); Munir (2010); Cormen et al. (2009)
        </p>

        <div class="border-t border-slate-200 my-10"></div>



        {{-- Aktivitas 1.1 --}}

        <div class="flex items-center gap-3 mb-6">
            <span class="bg-slate-900 text-white text-xs font-bold px-2 py-1 rounded uppercase">Aktivitas
                1.1</span>
            <h3 class="text-xl font-bold text-slate-900">Tantangan Abstraksi</h3>
        </div>

        {{-- PREMIS CERITA / SOAL CERITA --}}
        <div class="bg-blue-50 border border-blue-100 rounded-lg p-5 mb-8">
            <h4 class="font-bold text-blue-900 mb-3 text-sm flex items-center gap-2">
                Studi Kasus: Teknisi Jaringan di Kampus
            </h4>
            <div class="text-sm text-blue-800 leading-relaxed text-justify space-y-3">
                <p>
                    Budi adalah seorang teknisi jaringan baru di sebuah kampus. Ia
                    ditugaskan untuk memperbaiki koneksi internet yang sering terputus di <strong>"Lab
                        Komputer 1"</strong>.
                </p>
                <p>
                    Saat tiba di lokasi, Budi menemukan kondisi kabel jaringan
                    yang sangat berantakan di bawah meja kerja. Kabel-kabel hitam berseliweran, adaptor
                    tercampur, dan hub switch berada di tengah kekacauan tersebut (Perhatikan <strong>Gambar
                        A</strong>).
                </p>
                <p>
                    Karena tidak mungkin merapikan semua kabel secara fisik
                    dalam waktu singkat, Budi memutuskan untuk melakukan <em>abstraksi</em>. Ia menelusuri
                    jalur khusus milik "Lab Komputer 1" saja dengan mengidentifikasi:
                </p>
                <ul class="list-disc list-inside ml-4 space-y-1 text-blue-800">
                    <li>Hub/Switch yang berada di tengah sebagai <strong>titik pusat</strong></li>
                    <li>4 kabel yang terhubung ke komputer sebagai <strong>jalur koneksi</strong></li>
                    <li>Mengabaikan kabel-kabel lain yang tidak relevan dengan jaringan lab</li>
                </ul>
                <p>
                    Setelah itu, Budi menggambar ulang struktur jaringan tersebut menjadi <strong>diagram
                        topologi yang bersih dan terstruktur</strong> agar mudah dipahami oleh timnya dan
                    mempermudah troubleshooting di masa depan (Perhatikan <strong>Gambar B</strong>).
                </p>
                <p class="font-semibold text-blue-900 border-t border-blue-200 pt-3 mt-3">
                    <strong>Tugas Anda:</strong> Analisislah keputusan dan pola pikir yang dilakukan Budi
                    berdasarkan transformasi gambar di bawah ini.
                </p>
            </div>
        </div>

        <div class="grid md:grid-cols-2 gap-4 mb-8">
            <div class="bg-white p-2 rounded border border-slate-300 shadow-sm">
                <img src="{{ asset('images/semrawut.jpeg') }}" alt="Kabel Semrawut"
                    class="w-full h-48 object-cover rounded mb-2">
                <p class="text-xs text-slate-500 font-mono text-center font-bold">Gambar A: Kondisi Fisik
                    (Semrawut)</p>
            </div>
            <div class="bg-white p-2 rounded border border-slate-300 shadow-sm">
                <img src="{{ asset('images/topologi_star.png') }}" alt="Topologi Star"
                    class="w-full h-48 object-contain rounded mb-2">
                <p class="text-xs text-slate-500 font-mono text-center font-bold">Gambar B: Diagram Logika
                    (Rapi)</p>
            </div>
        </div>

        {{-- CONTAINER SOAL --}}
        <div class="space-y-8" id="quizContainer11">
            @foreach ($q1_1 as $index => $soal)
                {{-- TIDAK ADA LAGI data-correct DI SINI --}}
                <div class="quiz-item bg-white border border-slate-200 rounded-xl p-6 shadow-sm"
                    data-id="q{{ $index + 1 }}">

                    <div class="flex gap-2 mb-4 items-baseline">
                        <span class="text-slate-500 text-sm leading-relaxed font-medium">
                            {{ $index + 1 }}.
                        </span>
                        <div
                            class="question-text text-slate-800 text-sm leading-relaxed prose prose-sm max-w-none flex-1">
                            <div class="overflow-x-auto">
                                {!! $soal->question_text !!}
                            </div>
                        </div>
                    </div>

                    {{-- PILIHAN JAWABAN --}}
                    <div class="space-y-2">
                        @foreach ($soal->options as $key => $text)
                            <button type="button"
                                class="option-btn w-full text-left p-3 rounded border border-slate-200 hover:bg-slate-50 transition-colors flex gap-3 group"
                                onclick="selectOption11('q{{ $index + 1 }}', '{{ $key }}', this)"
                                data-option="{{ $key }}">

                                <span class="option-key font-bold text-slate-500">{{ $key }}.</span>
                                <span class="option-text text-slate-700">{{ $text }}</span>
                            </button>
                        @endforeach
                    </div>

                    {{-- FEEDBACK BOX --}}
                    <div id="feedback-q{{ $index + 1 }}"
                        class="hidden mt-4 p-4 rounded-lg bg-blue-50 border border-blue-200 text-slate-700 text-sm leading-relaxed">
                        <strong class="block text-blue-800 mb-1">💡 Pembahasan:</strong>
                        {!! $soal->explanation !!}
                    </div>
                </div>
            @endforeach
        </div>

        {{-- FOOTER --}}
        <div class="mt-6">
            @if (isset($progress['1.1']))
                {{-- SUDAH SELESAI: MODE REVIEW --}}
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4"
                    role="alert">
                    <div class="flex items-center gap-2">
                        <span class="text-2xl"></span>
                        <div>
                            <strong class="font-bold">Aktivitas Selesai!</strong>
                            <span class="block sm:inline">Nilai Anda: <span
                                    class="text-2xl font-bold">{{ $progress['1.1']->score }}</span></span>
                        </div>
                    </div>
                </div>

                {{-- SCRIPT KHUSUS 1.1 (MENGGUNAKAN DATA OBJECT) --}}
                <script>
                    document.addEventListener("DOMContentLoaded", function() {
                        // Ambil Data Kunci Global 1.1
                        const kunciJawaban = window.kunciJawaban11;

                        const container = document.getElementById('quizContainer11');
                        const items = container.querySelectorAll('.quiz-item');

                        items.forEach(item => {
                            // Ambil ID (q1, q2)
                            const qId = item.getAttribute('data-id');
                            const correctKey = kunciJawaban[qId];

                            // 1. Buka Feedback
                            const fb = item.querySelector('[id^="feedback-"]');
                            if (fb) fb.classList.remove('hidden');

                            // 2. Loop Tombol
                            const btns = item.querySelectorAll('.option-btn');
                            btns.forEach(btn => {
                                btn.disabled = true;
                                btn.classList.add('cursor-default');

                                const btnKey = btn.getAttribute('data-option');

                                // BANDINGKAN
                                if (btnKey.toUpperCase() === correctKey.toUpperCase()) {
                                    // HIJAU
                                    btn.classList.add('correct-answer');
                                    btn.classList.remove('hover:bg-slate-50', 'border-slate-200');
                                } else {
                                    // REDUP
                                    btn.classList.add('wrong-answer');
                                }
                            });
                        });

                        // Buka Tombol Next
                        const nextBtn = document.getElementById('btnNext11');
                        if (nextBtn) {
                            nextBtn.disabled = false;
                            nextBtn.classList.remove('opacity-50', 'cursor-not-allowed');
                        }
                    });
                </script>
            @else
                {{-- BELUM SELESAI --}}
                <div id="warning11"
                    class="hidden p-3 bg-yellow-50 border border-yellow-200 text-yellow-800 text-sm rounded text-center mb-3">
                    ⚠️ Silakan jawab semua pertanyaan.</div>
                <div id="error11"
                    class="hidden p-3 bg-red-50 border border-red-200 text-red-800 text-sm rounded text-center mb-3">
                    ❌ Masih ada jawaban yang kurang tepat.</div>
                <div id="success11"
                    class="hidden p-3 bg-green-50 border border-green-200 text-green-800 text-sm rounded text-center mb-3">
                    <strong>Sempurna!</strong>
                </div>

                <div class="flex justify-end">
                    <button onclick="checkAllAnswers11()"
                        class="bg-slate-800 hover:bg-slate-900 text-white px-6 py-2.5 rounded shadow-sm font-semibold text-sm transition-all active:scale-95">
                        Periksa Jawaban
                    </button>
                </div>
            @endif
        </div>

        <div class="flex justify-between gap-4 mt-8">
            <button type="button" onclick="prevStep()" class="btn-secondary">← Kembali</button>
            <button id="btnNext11" type="button" onclick="nextStep()" class="btn-primary opacity-50 cursor-not-allowed"
                disabled>Lanjut Materi →</button>
        </div>
    </div>

    {{-- GENERATE DATA KUNCI JAWABAN 1.1 --}}
    <script>
        // Data Kunci Jawaban Bersih untuk 1.1
        window.kunciJawaban11 = {
            @foreach ($q1_1 as $index => $soal)
                @php
                    // Logic pembersih yang sama persis
                    $clean = trim(str_replace(['"', "'"], '', $soal->correct_answer));
                    $clean = strtoupper($clean);
                @endphp
                    'q{{ $index + 1 }}': "{{ $clean }}",
            @endforeach
        };

        // Data Quiz untuk Logic Manual
        window.quizData11 = {
            @foreach ($q1_1 as $index => $soal)
                'q{{ $index + 1 }}': {
                    correct: '{{ strtoupper(trim(str_replace(['"', "'"], '', $soal->correct_answer))) }}',
                    weight: {{ $soal->weight ?? 10 }},
                    explanation: '{!! addslashes($soal->explanation) !!}'
                }
                @if (!$loop->last)
                    ,
                @endif
            @endforeach
        };
    </script>

</section>
