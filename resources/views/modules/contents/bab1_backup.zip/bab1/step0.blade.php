<section id="step-0" class="step-slide">
    <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-8 md:p-10">
        <div class="grid md:grid-cols-2 gap-10 items-center">

            {{-- Kolom Kiri: Narasi --}}
            <div>
                <h2 class="text-2xl md:text-3xl font-bold mb-6 text-slate-900">
                    Bab 1: Dasar - Dasar Graf
                </h2>

                <div class="prose prose-slate text-slate-600 leading-relaxed text-justify">
                    <p class="mb-4">
                        Tata kota Banjarmasin yang dipenuhi sungai dan jembatan menghadirkan tantangan
                        tersendiri
                        dalam menentukan arah perjalanan.
                    </p>
                    <p class="mb-8">
                        Pernahkah terlintas di benakmu bagaimana <strong>Google Maps</strong> bisa
                        merekomendasikan
                        rute paling efisien melewati banyak jembatan tersebut? Jawabannya terletak pada struktur
                        data bernama <strong>Graf</strong> yang bekerja senyap di balik layar.
                    </p>
                </div>

                <button onclick="nextStep()"
                    class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2.5 px-6 rounded-lg transition-colors shadow-sm">
                    Mulai Pembelajaran
                </button>
            </div>

            {{-- Kolom Kanan: Gambar --}}
            <div>
                <div class="rounded-xl overflow-hidden shadow-lg border border-slate-100">
                    <img src="{{ asset('images/banjarmasin.jpg') }}" alt="Jembatan Sei Alalak"
                        class="w-full h-auto object-cover grayscale-[10%] hover:grayscale-0 transition-all duration-500">

                    <div class="bg-slate-900 p-4">
                        <p class="text-white font-medium text-sm">Jembatan Sei Alalak</p>
                        <p class="text-slate-400 text-xs mt-1">
                            Di mata manusia, ini adalah infrastruktur megah. Namun dalam logika komputer, ini
                            hanyalah
                            sebuah "Garis" yang berfungsi menghubungkan dua titik lokasi.
                        </p>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
