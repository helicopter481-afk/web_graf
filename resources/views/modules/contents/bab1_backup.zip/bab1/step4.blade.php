<section id="step-4" class="step-slide">
    <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-10">

        {{-- Header --}}
        <div class="border-b border-slate-200 pb-6 mb-8">
            <h2 class="text-3xl font-bold text-slate-900 mb-2">1.3 Representasi Graf dalam Kehidupan Nyata</h2>
            <p class="text-slate-500 font-medium text-sm">Memahami aplikasi graf pada sistem transportasi,
                jejaring sosial, dan e-commerce.</p>
        </div>

        {{-- Intro Text --}}
        <div class="mb-8 text-slate-700 leading-relaxed text-m space-y-4 text-justify">
            <p>
                Graf bukan sekadar entitas matematika abstrak, melainkan merupakan struktur fundamental yang
                menopang berbagai teknologi modern. Dalam praktiknya, graf digunakan untuk memodelkan hubungan
                antarobjek yang saling terhubung. Graf dimanfaatkan secara luas untuk merepresentasikan struktur
                dalam berbagai bidang, seperti jaringan transportasi, jaringan komunikasi, hingga interaksi
                sosial
            </p>
            <p>
                Untuk memahami relevansi graf secara lebih konkret, pada submateri ini akan dibahas dua contoh
                penerapan graf yang sering dijumpai dalam kehidupan sehari-hari, yaitu pada sistem transportasi
                dan
                pada jejaring sosial.
            </p>
        </div>

        {{-- BRIDGING OJOL (Tanpa Definisi Vertex/Edge Awal) --}}
        <p class="text-xl mb-8 text-center"><strong>Penerapan Graf pada Sistem Transportasi dan
                Navigasi</strong>
        </p>
        <div class="mb-10 text-justify">
            <div class="mb-6">
                <p class="text-slate-700 leading-relaxed mb-4">
                    Salah satu penerapan graf yang paling krusial terdapat pada sistem transportasi dan
                    navigasi.
                    Aplikasi peta digital dan layanan transportasi daring memodelkan suatu wilayah sebagai
                    jaringan
                    lokasi yang saling terhubung. Dalam model ini, setiap lokasi direpresentasikan sebagai
                    simpul,
                    sedangkan jalan yang menghubungkan lokasi-lokasi tersebut direpresentasikan sebagai sisi.
                </p>
                <p class="mb-4">Sebelum membahas lebih jauh konsep algoritmik di baliknya, perhatikan
                    simulasi
                    berikut untuk
                    memahami cara kerja logika navigasi secara intuitif.</p>

                <div class="bg-blue-50 border-l-4 border-blue-500 p-5 rounded-r shadow-sm mb-6">
                    <h4 class="font-bold text-blue-900 text-base mb-2 flex items-center gap-2">Misi: Menjadi
                        "Otak" Sistem Navigasi</h4>
                    <p class="text-sm text-blue-800 leading-relaxed text-justify mb-3">
                        Bayangkan Anda adalah sistem algoritma di balik aplikasi ojek online. Tugas Anda adalah
                        memandu driver dari posisi awal (Rumah) untuk <strong>menjemput penumpang di
                            Pasar</strong>, lalu <strong>mengantarnya ke Kampus</strong>.
                    </p>
                    <div class="bg-white/60 p-3 rounded border border-blue-100 text-xs text-blue-900 font-medium">
                        <strong>Panduan:</strong> Klik pada lingkaran lokasi (simpul) untuk memindahkan
                        kendaraan.
                        Pergerakan hanya dapat dilakukan jika terdapat garis jalan (sisi) yang menghubungkan dua
                        lokasi.
                    </div>
                </div>
            </div>

            {{-- === SIMULASI OJEK ONLINE === --}}
            <div id="ojekApp" class="sim-card max-w-[900px] mx-auto">
                <header class="ojek-header">
                    <div class="ojek-header-text">
                        <h2>Simulasi Navigasi Graf</h2>
                        <p>Tugas: Lakukan penjemputan di <b>Pasar</b>, lalu antar ke <b>Kampus</b>.</p>
                    </div>
                    <div class="status-badge" id="mission-status">Status: Menunggu Penjemputan</div>
                </header>
                <div class="map-container">
                    <div id="toast-msg" class="toast-ojek">Notifikasi</div>
                    <svg viewBox="0 0 900 500">
                        <g id="edges-layer">
                            <path id="e-Rumah-Taman" class="edge-path" d="M150 250 L400 100" />
                            <path id="e-Rumah-Pasar" class="edge-path" d="M150 250 L400 400" />
                            <path id="e-Taman-Kampus" class="edge-path" d="M400 100 L750 250" />
                            <path id="e-Pasar-Kampus" class="edge-path" d="M400 400 L750 250" />
                            <path id="e-Taman-Pasar" class="edge-path" d="M400 100 L400 400" />
                        </g>
                        <g id="nodes-layer">
                            <g class="node-ojek" id="n-Rumah" onclick="movePlayer('Rumah', 150, 250)">
                                <circle cx="150" cy="250" r="32" /><text x="150" y="250"
                                    class="icon">🏠</text><text x="150" y="300" class="label">Rumah</text>
                            </g>
                            <g class="node-ojek transit" id="n-Taman" onclick="movePlayer('Taman', 400, 100)">
                                <circle cx="400" cy="100" r="32" /><text x="400" y="100"
                                    class="icon">🌳</text><text x="400" y="150" class="label">Taman</text>
                            </g>
                            <g class="node-ojek" id="n-Pasar" onclick="movePlayer('Pasar', 400, 400)">
                                <circle cx="400" cy="400" r="32" /><text x="400" y="400"
                                    class="icon">🛒</text><text x="400" y="450" class="label">Pasar</text>
                            </g>
                            <g class="node-ojek" id="n-Kampus" onclick="movePlayer('Kampus', 750, 250)">
                                <circle cx="750" cy="250" r="32" /><text x="750" y="250"
                                    class="icon">🎓</text><text x="750" y="300" class="label">Kampus</text>
                            </g>
                        </g>
                        <text id="motor" x="0" y="0" transform="translate(150, 250)">🛵</text>
                    </svg>
                </div>
                <footer class="ojek-footer">
                    <div id="instruction">Posisi Awal: <b>Rumah</b>. Klik lokasi tujuan untuk berpindah.</div>
                    <button class="btn-reset-ojek" onclick="resetOjekGame()">Reset Simulasi</button>
                </footer>
            </div>

            {{-- PANEL ANALISIS EDUKASI (MUNCUL OTOMATIS) --}}
            <div id="edu-panel" class="edu-content" style="display: none;">
                <h3>Hasil Analisis Simulasi</h3>
                <div class="feedback-box">
                    <span class="feedback-title">Evaluasi Lintasan:</span>
                    <div id="feedback-text" class="feedback-text"></div>
                </div>
                <p>Berdasarkan simulasi yang telah dilakukan, berikut adalah implementasi konsep struktur data
                    Graf dalam konteks navigasi:</p>
                <ul class="concept-list">
                    <li><strong>Simpul (Vertex):</strong> Merepresentasikan entitas lokasi seperti Rumah, Pasar,
                        dan Kampus.</li>
                    <li><strong>Sisi (Edge):</strong> Merepresentasikan jalan raya yang menghubungkan
                        lokasi-lokasi
                        tersebut. Dalam peta digital, Sisi (Jalan) biasanya memiliki Bobot (Weight) yang
                        merepresentasikan jarak atau waktu tempuh.</li>
                    <li><strong>Lintasan (Path):</strong> Urutan simpul yang dikunjungi dari titik awal hingga
                        tujuan akhir.</li>
                </ul>
                <p style="margin-top: 20px; font-size: 14px; border-top: 1px solid #f1f5f9; padding-top: 15px;">
                    <em>Catatan:</em> Pada Bab 1 ini, setiap sisi dianggap memiliki bobot yang sama. Konsep
                    optimasi rute berdasarkan jarak (km) menggunakan <strong>Algoritma Dijkstra</strong> pada
                    <em>Weighted Graph</em> akan dibahas secara mendalam pada Bab 5.
                </p>
                <p>Melalui simulasi ini, dapat dipahami bahwa sistem navigasi tidak bekerja berdasarkan peta
                    visual
                    semata, melainkan berdasarkan struktur hubungan antar lokasi yang dimodelkan dalam bentuk
                    graf.
                </p>
            </div>
        </div>

        <div class="section-divider my-10 border-t border-slate-200"></div>

        {{-- BRIDGING MEDSOS --}}
        <p class="text-xl mb-8 text-center"><strong>Penerapan Graf pada Jejaring Sosial</strong>
        <div class="mb-10">
            <p class="text-slate-700 leading-relaxed text-justify mb-4">
                Selain pada sistem transportasi, graf juga menjadi fondasi utama dalam analisis jejaring sosial.
                Media sosial membangun graf pertemanan berskala besar untuk merepresentasikan hubungan antar
                pengguna. Setiap pengguna direpresentasikan sebagai simpul, sedangkan hubungan pertemanan
                direpresentasikan sebagai sisi.
            </p>

            {{-- PENJELASAN KONTEKS VISUAL (DIPERTAHANKAN) --}}
            <ul class="list-disc list-inside space-y-2 mb-6 ml-2 text-base text-slate-700">
                <li><strong>Simpul (Vertex):</strong> Merepresentasikan akun pengguna (User) seperti Andi, Budi,
                    Citra,
                    Dani.</li>
                <li><strong>Sisi (Edge):</strong> Diwakili oleh garis yang menghubungkan dua profil (menandakan
                    status berteman).</li>
            </ul>

            <p class="mb-4 text-slate-700 text-base text-justify">
                Salah satu fitur yang sering dijumpai pada media sosial adalah rekomendasi <em>“Teman yang
                    Mungkin
                    Anda
                    Kenal”</em>. Fitur ini bekerja dengan menelusuri struktur graf pertemanan, misalnya dengan
                mencari pola
                hubungan teman dari teman. Untuk memahami konsep tersebut, silakan lakukan simulasi interaktif
                di
                bawah ini dan amati bagaimana koneksi antar pengguna dapat terbentuk melalui jalur tertentu
                dalam
                graf.
            </p>

            {{-- === SIMULASI SOSMED NEW === --}}
            <div id="app-medsos">
                <header class="medsos-header">
                    <h2>Simulasi Struktur Data Graf: Interaksi Sosial</h2>
                    <div class="guide-box text-sm">
                        <p class="font-semibold mb-2">Panduan Penggunaan:</p>

                        <ul class="list-disc list-inside pl-6 space-y-2">
                            <li>Posisi awal berada pada simpul <b>Andi</b>.</li>
                            <li>Tujuan akhir adalah mencapai simpul <b>Dani</b>.</li>
                            <li>Klik pada simpul teman yang terhubung langsung (bertetangga) untuk membuat
                                jalur.
                            </li>
                            <li>Perhatikan bagaimana garis (Sisi) terbentuk saat Anda memilih jalur yang valid.
                            </li>
                        </ul>
                    </div>


                </header>
                <div class="graph-area-medsos">
                    <div id="toast-msg-medsos" class="toast-medsos">Peringatan: Simpul tidak terhubung
                        langsung.</div>
                    <svg viewBox="0 0 800 400">
                        <defs>
                            <symbol id="icon-user-medsos" viewBox="0 0 24 24">
                                <path
                                    d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
                            </symbol>
                        </defs>
                        <g id="edges-medsos">
                            <path id="e-Andi-Budi" class="link-medsos" d="M150 200 L400 80" />
                            <path id="e-Andi-Citra" class="link-medsos" d="M150 200 L400 320" />
                            <path id="e-Budi-Dani" class="link-medsos" d="M400 80 L650 200" />
                            <path id="e-Citra-Dani" class="link-medsos" d="M400 320 L650 200" />
                            <path id="e-Budi-Citra" class="link-medsos" d="M400 80 L400 320" />
                        </g>
                        <g id="nodes-medsos">
                            <g class="node-medsos active" id="n-Andi" onclick="handleMedsosClick('Andi')">
                                <circle cx="150" cy="200" r="35" />
                                <use href="#icon-user-medsos" x="130" y="180" width="40" height="40"
                                    class="user-icon-medsos" /><text x="150" y="260" class="label-medsos">Andi</text>
                            </g>
                            <g class="node-medsos" id="n-Budi" onclick="handleMedsosClick('Budi')">
                                <circle cx="400" cy="80" r="35" />
                                <use href="#icon-user-medsos" x="380" y="60" width="40" height="40"
                                    class="user-icon-medsos" /><text x="400" y="30" class="label-medsos">Budi</text>
                            </g>
                            <g class="node-medsos" id="n-Citra" onclick="handleMedsosClick('Citra')">
                                <circle cx="400" cy="320" r="35" />
                                <use href="#icon-user-medsos" x="380" y="300" width="40" height="40"
                                    class="user-icon-medsos" /><text x="400" y="380" class="label-medsos">Citra</text>
                            </g>
                            <g class="node-medsos" id="n-Dani" onclick="handleMedsosClick('Dani')">
                                <circle cx="650" cy="200" r="35" />
                                <use href="#icon-user-medsos" x="630" y="180" width="40" height="40"
                                    class="user-icon-medsos" /><text x="650" y="260" class="label-medsos">Dani</text>
                            </g>
                        </g>
                    </svg>
                </div>
                <footer class="medsos-footer">
                    <div id="instruction-medsos">Posisi saat ini: <b>Andi</b>. Menunggu input pengguna...</div>
                    <button class="btn-reset-medsos" onclick="resetMedsosGraph()">Reset Simulasi</button>
                </footer>
            </div>

            <div id="analysis-panel-medsos">
                <span class="analysis-title-medsos">Hasil Analisis Graf</span>
                <div id="analysis-text-medsos" class="analysis-text-medsos"></div>
            </div>
        </div>
        <p class="text-slate-700 text-base leading-relaxed mb-6 text-justify">
            Dari dua contoh penerapan di atas, terlihat bahwa graf digunakan untuk memodelkan permasalahan nyata
            dengan fokus pada hubungan antarobjek, bukan pada detail visualnya. Baik dalam sistem navigasi
            maupun
            jejaring sosial, keputusan sistem ditentukan oleh struktur graf yang terbentuk.
        </p>

        <div class="section-divider my-10 border-t border-slate-200"></div>

        {{-- BRIDGING AKTIVITAS 1.3 --}}
        <p class="text-slate-700 text-base leading-relaxed mb-6 text-justify">
            Setelah melihat bagaimana graf bekerja di transportasi dan media sosial, sekarang giliran Anda untuk
            mempraktikkan pemahaman tersebut. Dalam dunia industri, seorang Data Engineer harus mampu memilah
            data
            mana yang relevan untuk dimodelkan sebagai graf dan mana yang tidak.
        </p>

        {{-- ========================================================= --}}
        {{-- START: AKTIVITAS 1.3 (MULTI DRAG & DROP SUPPORT) --}}
        {{-- ========================================================= --}}

        @if (isset($q1_3_list) && count($q1_3_list) > 0)

            @foreach ($q1_3_list as $index => $soal)
                <div class="bg-white rounded-lg border border-slate-300 shadow-sm overflow-hidden mb-12 mt-8 drag-container"
                    id="game-container-{{ $soal->id }}">

                    {{-- Header Soal --}}
                    <div class="bg-amber-50 p-6 border-b border-amber-100">
                        <div class="flex items-center gap-3 mb-2">
                            <span
                                class="bg-amber-100 text-amber-800 text-xs font-bold px-2 py-1 rounded border border-amber-200 uppercase">
                                Aktivitas 1.3
                            </span>
                            <h3 class="text-lg font-bold text-slate-900">
                                Bedah Data E-Commerce {{ $index > 0 ? '(Soal Tambahan #' . $index . ')' : '' }}
                            </h3>
                        </div>

                        <div class="text-slate-700 text-sm leading-relaxed mb-2">
                            {!! $soal->question_text !!}
                        </div>

                        <p class="text-slate-500 text-xs italic">
                            Catatan: Biarkan item data yang <strong>bukan struktur graf (Pengecoh)</strong>
                            tetap
                            berada di tempat asalnya.
                        </p>
                    </div>

                    {{-- Area Game --}}
                    <div class="p-6 bg-slate-50">

                        {{-- SOURCE AREA --}}
                        <div class="mb-6">
                            <p class="text-xs font-bold text-slate-500 uppercase mb-3 tracking-wider">
                                ITEM DATA (TARIK DARI SINI)
                            </p>
                            <div id="dragSource-{{ $soal->id }}"
                                class="drop-zone flex flex-wrap gap-2 min-h-[80px] p-4 border-2 border-dashed border-slate-300 rounded-lg bg-white items-start transition-colors"
                                data-category="source" data-game-id="{{ $soal->id }}">
                            </div>
                        </div>

                        {{-- TARGET AREAS --}}
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">

                            {{-- Vertex --}}
                            <div class="drop-zone bg-white border border-blue-200 rounded-lg shadow-sm flex flex-col"
                                data-category="vertex" data-game-id="{{ $soal->id }}">
                                <div class="bg-blue-50 px-4 py-2 border-b border-blue-100 flex items-center gap-2">
                                    <div class="w-2 h-2 rounded-full bg-blue-600"></div>
                                    <h4 class="font-bold text-blue-900 text-xs uppercase tracking-wide">
                                        Simpul (Vertex)
                                    </h4>
                                </div>
                                <div class="zone-content min-h-[120px] p-3 flex flex-col gap-2 bg-white flex-grow">
                                </div>
                            </div>

                            {{-- Edge --}}
                            <div class="drop-zone bg-white border border-green-200 rounded-lg shadow-sm flex flex-col"
                                data-category="edge" data-game-id="{{ $soal->id }}">
                                <div class="bg-green-50 px-4 py-2 border-b border-green-100 flex items-center gap-2">
                                    <div class="w-6 h-1 rounded bg-green-600"></div>
                                    <h4 class="font-bold text-green-900 text-xs uppercase tracking-wide">
                                        Sisi (Edge)
                                    </h4>
                                </div>
                                <div class="zone-content min-h-[120px] p-3 flex flex-col gap-2 bg-white flex-grow">
                                </div>
                            </div>

                            {{-- Degree --}}
                            <div class="drop-zone bg-white border border-purple-200 rounded-lg shadow-sm flex flex-col"
                                data-category="degree" data-game-id="{{ $soal->id }}">
                                <div class="bg-purple-50 px-4 py-2 border-b border-purple-100 flex items-center gap-2">
                                    <span
                                        class="font-bold text-purple-700 text-[10px] border border-purple-400 px-1 rounded bg-white">
                                        123
                                    </span>
                                    <h4 class="font-bold text-purple-900 text-xs uppercase tracking-wide">
                                        Derajat (Degree)
                                    </h4>
                                </div>
                                <div class="zone-content min-h-[120px] p-3 flex flex-col gap-2 bg-white flex-grow">
                                </div>
                            </div>
                        </div>

                        {{-- FEEDBACK AREA --}}
                        <div class="mt-8 pt-6 border-t border-slate-200">
                            <div id="status-{{ $soal->id }}"
                                class="hidden mb-4 p-3 rounded text-sm text-center font-medium"></div>

                            <div id="explain-{{ $soal->id }}"
                                class="hidden bg-green-50 border border-green-200 rounded-lg p-4 mb-4 text-slate-800 text-sm leading-relaxed">
                                {!! $soal->explanation !!}
                            </div>

                            <div class="flex justify-end gap-3">
                                <button onclick="initDragGame('{{ $soal->id }}', null)"
                                    class="px-4 py-2 bg-white border border-slate-300 text-slate-600 text-xs font-bold rounded hover:bg-slate-50 transition-colors">
                                    Reset
                                </button>

                                <button onclick="checkGameAnswer('{{ $soal->id }}')"
                                    class="px-5 py-2 bg-slate-900 text-white text-xs font-bold rounded hover:bg-slate-800 transition-colors shadow-sm active:scale-95">
                                    Periksa Jawaban
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <script>
                    document.addEventListener('DOMContentLoaded', function() {

                        var rawData = {!! json_encode($soal->options) !!};

                        @php
                            $saved = $progress['1.3']->answer ?? null;
                        @endphp

                        var savedAnswer = {!! json_encode($saved) !!};

                        initDragGame('{{ $soal->id }}', rawData, savedAnswer);

                    });
                </script>
            @endforeach
        @else
            <div class="bg-red-50 border border-red-200 text-red-700 p-4 rounded text-center">
                <strong>Debug:</strong> Data Soal 1.3 Kosong.
                Pastikan Controller mengirim variabel <code>$q1_3_list</code>.
            </div>
        @endif



    </div>

    {{-- Navigasi --}}
    <div class="flex justify-between gap-4 mt-8">
        <button type="button" onclick="prevStep()" class="btn-secondary">← Kembali ke 1.2</button>
        <button type="button" onclick="nextStep()" class="btn-primary">Lanjut ke Rangkuman →</button>
    </div>
    </div>
</section>
